#include <GadgetWork.h>


ZyanStatus ZydisInit(ZydisDecoder* decoder, ZydisFormatter* formatter) {
    ZyanStatus status = ZYAN_STATUS_SUCCESS;
    status = ZydisDecoderInit(decoder, ZYDIS_MACHINE_MODE_LONG_COMPAT_32, ZYDIS_ADDRESS_WIDTH_32);
    if (!ZYAN_SUCCESS(status)) {
        printf("[Zydis] Error zydis decoder init\n");
        return status;
    }

    if (formatter) {
        if (!ZYAN_SUCCESS((status = ZydisFormatterInit(formatter, ZYDIS_FORMATTER_STYLE_INTEL)))) {
            printf("[Zydis] Error init formatter\n");
            return status;
        }
        if (!ZYAN_SUCCESS((status = ZydisFormatterSetProperty(formatter, ZYDIS_FORMATTER_PROP_FORCE_SIZE, ZYAN_TRUE)))) {
            printf("[Zydis] Error set prop formatter\n");
            return status;
        }
    }

    return status;
}

ULONG FindGadget(PGADGET gadget, std::vector<KERNEL_MODULE>& modules) {

    ZydisDecoder decoder;
    ZydisFormatter formatter;
    ZyanStatus status = ZydisInit(&decoder, &formatter);
    if (!ZYAN_SUCCESS(status)) {
        return 0;
    }

    char format_buffer1[64];
    char format_buffer2[64];

    for (KERNEL_MODULE& mod : modules) {
        for (int i = 0; i < mod.secCount; ++i) {
            ULONG mainOffset = 0;
            PIMAGE_SECTION_HEADER currSection = &mod.codeSections[i];
            ULONG secLen = currSection->SizeOfRawData;
            ZydisDecodedInstruction currInstr;
            ZyanU32 instrAddr;
            while ((instrAddr = (ZyanU32)((mod.pe.mem + currSection->VirtualAddress) + mainOffset),
                (status = ZydisDecoderDecodeBuffer(&decoder,
                    (LPVOID)instrAddr,
                    secLen - mainOffset,
                    &currInstr) != ZYDIS_STATUS_NO_MORE_DATA))) {

                if (!ZYAN_SUCCESS(status)) {
                    mainOffset++;
                    continue;
                }
                ULONG tmpOffset = mainOffset + currInstr.length;
                if (currInstr.mnemonic == gadget->mnem) {
                    if (!memcmp((LPVOID)&currInstr.operands[0], (LPVOID)&gadget->op0, sizeof(ZydisDecodedOperand)) &&
                        !memcmp((LPVOID)&currInstr.operands[1], (LPVOID)&gadget->op1, sizeof(ZydisDecodedOperand)) &&
                        !memcmp((LPVOID)&currInstr.operands[2], (LPVOID)&gadget->op2, sizeof(ZydisDecodedOperand))) {

                        // ����� ������ ����������
                        // ���� ����� ret � ������������� �� ������� ������������� ����������, ����� ��������� ���-�� ����� ret
                        
                        ZydisDecodedInstruction nextInstr;
                        ULONG instrCount = 0;
                        ZyanU32 addr;
                        while ((addr = (ZyanU32)((mod.pe.mem + currSection->VirtualAddress) + tmpOffset),
                            (status = ZydisDecoderDecodeBuffer(&decoder,
                                (LPVOID)addr,
                                secLen - tmpOffset,
                                &nextInstr) != ZYDIS_STATUS_NO_MORE_DATA))) {

                            if (!ZYAN_SUCCESS(status)) {
                                tmpOffset++;
                                continue;
                            }
                            
                            if (nextInstr.mnemonic == ZYDIS_MNEMONIC_RET) {
                                gadget->countRet = nextInstr.operands[0].imm.value.u;
                                if (gadget->countRet <= 0x0c) {
                                    return mod.base + currSection->VirtualAddress + mainOffset;
                                }
                            }
                            BOOL stop = FALSE;
                            tmpOffset += nextInstr.length;
                            instrCount++;
                            if (instrCount > gadget->countIncInstr) {
                                break;
                            }
                            if (gadget->excludedInstrs != NULL) {
                                int ind = 0;
                                while (gadget->excludedInstrs[ind].p != FALSE) {
                                    if (gadget->excludedInstrs[ind].mnemPriority &&
                                        gadget->excludedInstrs[ind].mnem == nextInstr.mnemonic) {

                                        stop = TRUE;
                                        break;
                                    }
                                    else if (((gadget->excludedInstrs[ind].optype0 == ZYDIS_OPERAND_TYPE_REGISTER &&
                                        gadget->excludedInstrs[ind].reg0 == nextInstr.operands[0].reg.value) ||
                                        (gadget->excludedInstrs[ind].optype1 == ZYDIS_OPERAND_TYPE_REGISTER &&
                                            gadget->excludedInstrs[ind].reg1 == nextInstr.operands[1].reg.value) ||
                                        (nextInstr.operands[0].type == ZYDIS_OPERAND_TYPE_MEMORY &&
                                            gadget->excludedInstrs[ind].reg0 == nextInstr.operands[0].mem.base) ||
                                        (nextInstr.operands[1].type == ZYDIS_OPERAND_TYPE_MEMORY &&
                                            gadget->excludedInstrs[ind].reg1 == nextInstr.operands[1].mem.base)) &&
                                        (gadget->excludedInstrs[ind].mnem == nextInstr.mnemonic)) {

                                        stop = TRUE;
                                        break;
                                    }
                                    ind++;
                                }
                                if (stop) break;
                            }
                        }
                    }
                }
                mainOffset = tmpOffset;
            }
        }
    }

    return 0;
}

ULONG FindGadgetEx(PGADGET gadgets, ULONG gadCount, PEXCLUDED_TYPE excludedInstrs, std::vector<KERNEL_MODULE>& modules) {

    ZydisDecoder decoder;
    ZydisFormatter formatter;
    ZyanStatus status = ZydisInit(&decoder, &formatter);
    if (!ZYAN_SUCCESS(status)) {
        return 0;
    }

    char format_buffer1[64];
    char format_buffer2[64];

    for (KERNEL_MODULE& mod : modules) {
        for (int i = 0; i < mod.secCount; ++i) {
            ULONG mainOffset = 0;
            PIMAGE_SECTION_HEADER currSection = &mod.codeSections[i];
            ULONG secLen = currSection->SizeOfRawData;
            ZydisDecodedInstruction currInstr;
            ZyanU32 instrAddr;
            while ((instrAddr = (ZyanU32)((mod.pe.mem + currSection->VirtualAddress) + mainOffset),
                (status = ZydisDecoderDecodeBuffer(&decoder,
                    (LPVOID)instrAddr,
                    secLen - mainOffset,
                    &currInstr) != ZYDIS_STATUS_NO_MORE_DATA))) {

                if (!ZYAN_SUCCESS(status)) {
                    mainOffset++;
                    continue;
                }
                ULONG index = 0;
                ULONG tmpOffset = mainOffset + currInstr.length;
                if (currInstr.mnemonic == gadgets[index].mnem) {
                    if (!memcmp((LPVOID)&currInstr.operands[0], (LPVOID)&gadgets[index].op0, sizeof(ZydisDecodedOperand)) &&
                        !memcmp((LPVOID)&currInstr.operands[1], (LPVOID)&gadgets[index].op1, sizeof(ZydisDecodedOperand)) &&
                        !memcmp((LPVOID)&currInstr.operands[2], (LPVOID)&gadgets[index].op2, sizeof(ZydisDecodedOperand))) {

                        if (index == gadCount) {
                            if (currInstr.mnemonic == ZYDIS_MNEMONIC_RET) {
                                gadgets[index - 1].countRet = currInstr.operands[0].imm.value.u;
                            }
                            return mod.base + currSection->VirtualAddress + mainOffset;
                        }

                        ZydisDecodedInstruction nextInstr;
                        ULONG instrCount = 0;
                        ZyanU32 addr;
                        while ((addr = (ZyanU32)((mod.pe.mem + currSection->VirtualAddress) + tmpOffset),
                            (status = ZydisDecoderDecodeBuffer(&decoder,
                                (LPVOID)addr,
                                secLen - tmpOffset,
                                &nextInstr) != ZYDIS_STATUS_NO_MORE_DATA))) {

                            if (!ZYAN_SUCCESS(status)) {
                                tmpOffset++;
                                continue;
                            }

                            tmpOffset += nextInstr.length;
                            if (nextInstr.mnemonic != gadgets[index + 1].mnem) {
                                if (excludedInstrs != NULL) {
                                    BOOL stop = FALSE;
                                    

                                    int ind = 0;
                                    while (excludedInstrs[ind].p != FALSE) {
                                        if (excludedInstrs[ind].mnemPriority &&
                                            excludedInstrs[ind].mnem == nextInstr.mnemonic) {

                                            stop = TRUE;
                                            break;
                                        }
                                        else if((excludedInstrs[ind].optype1 == ZYDIS_OPERAND_TYPE_REGISTER && 
                                            excludedInstrs[ind].reg1 == ZYDIS_REGISTER_EIP) &&
                                            (excludedInstrs[ind].optype1 == ZYDIS_OPERAND_TYPE_REGISTER &&
                                                excludedInstrs[ind].reg1 == nextInstr.operands[1].reg.value)) {

                                            stop = TRUE;
                                            break;
                                        }
                                        else if (((excludedInstrs[ind].optype0 == ZYDIS_OPERAND_TYPE_REGISTER &&
                                            excludedInstrs[ind].reg0 == nextInstr.operands[0].reg.value) ||
                                            (excludedInstrs[ind].optype1 == ZYDIS_OPERAND_TYPE_REGISTER &&
                                                excludedInstrs[ind].reg1 == nextInstr.operands[1].reg.value) ||
                                            (nextInstr.operands[0].type == ZYDIS_OPERAND_TYPE_MEMORY &&
                                                excludedInstrs[ind].reg0 == nextInstr.operands[0].mem.base) ||
                                            (nextInstr.operands[1].type == ZYDIS_OPERAND_TYPE_MEMORY &&
                                                excludedInstrs[ind].reg1 == nextInstr.operands[1].mem.base)) &&
                                            (excludedInstrs[ind].mnem == nextInstr.mnemonic)) {

                                            stop = TRUE;
                                            break;
                                        }
                                        ind++;
                                    }
                                    if (stop) break;
                                }
                                
                                instrCount++;
                                if (instrCount > gadgets->countIncInstr) {
                                    break;
                                }
                                
                            }
                            else {
                                index++;
                                if (index == gadCount - 1) {
                                    if (nextInstr.mnemonic == ZYDIS_MNEMONIC_RET) {
                                        if (nextInstr.operands[0].imm.value.u > 0x20) {
                                            break;
                                        }
                                        gadgets[0].countRet = nextInstr.operands[0].imm.value.u;
                                    }
                                    return mod.base + currSection->VirtualAddress + mainOffset;
                                }
                            }
                        }
                    }
                }
                mainOffset = tmpOffset;
            }
        }
    }

    return 0;
}

//
// ������������ �������� ��� � ������� ���������� fasm.
//
BYTE* AssembleFasm32(char* srcCode, int* codeSize) {

    FASM_STATE* state;
    BYTE* code;
    char* srcCode32;

    srcCode32 = (char*)malloc(strlen(srcCode) + 6 + 1);

    // ��������� ����� �������� ����� ������ use32
    strcpy(srcCode32, "use32\n");
    strcat(srcCode32, srcCode);

    state = (FASM_STATE*)malloc(1024 * 1024);
    if (!fasm_Assemble(srcCode32, state, 1024 * 1024, 100, NULL)) {
        *codeSize = state->output_length;
        code = (BYTE*)malloc(state->output_length);
        memcpy(code, state->output_data, state->output_length);
    }
    else {
        *codeSize = 0;
        code = NULL;
    }

    free(state);
    free(srcCode32);

    return code;
}

BOOL InitGadget(const char* strGadget, int* opcodeSize, PGADGET gad, PEXCLUDED_TYPE excludedInstrs, ULONG countIncInstr) {

    PBYTE gadCode = AssembleFasm32((char*)strGadget, opcodeSize);
    if (gadCode) {
        ZydisDecodedInstruction instr;
        ZyanStatus status;
        ZydisDecoder decoder;
        status = ZydisInit(&decoder, NULL);
        if (!ZYAN_SUCCESS(status)) {
            return FALSE;
        }
        status = ZydisDecoderDecodeBuffer(&decoder,
            gadCode,
            *opcodeSize,
            &instr);
        if (!ZYAN_SUCCESS(status)) {
            printf("[GADGET] Error decode gadget init\n");
            return FALSE;
        }
        
        
        gad->mnem = instr.mnemonic;
        memcpy(&gad->op0, &instr.operands[0], sizeof(ZydisDecodedOperand));
        memcpy(&gad->op1, &instr.operands[1], sizeof(ZydisDecodedOperand));
        memcpy(&gad->op2, &instr.operands[2], sizeof(ZydisDecodedOperand));
        gad->countIncInstr = countIncInstr;
        gad->excludedInstrs = excludedInstrs;
    }
    else {
        free(gadCode);
        return FALSE;
    }

    free(gadCode);
    return TRUE;
}

ULONG FindRopGadget(std::vector<KERNEL_MODULE>& modules, char* strGadget, PULONG countRet, PEXCLUDED_TYPE excludedInstrs, ULONG countIncInstr) {
    
    ULONG gadAddr = 0;
    int opcodeSize;
    char* str = (char*)malloc(128);
    char* subStr = strGadget;
    RtlZeroMemory(str, 128);
    int count = 1;
    std::vector<char*> gadgets;

    while (true) {
        gadgets.push_back(subStr);
        if ((subStr = strchr(strGadget, '\n')) != NULL) {
            subStr[0] = '\0';
            subStr++;
            count++;
        }
        else {
            break;
        }
    }
    PGADGET gad = (PGADGET)malloc(sizeof(GADGET) * count);
    for (int i = 0; i < count; ++i) {
        if (!InitGadget(gadgets[i], &opcodeSize, &gad[i], excludedInstrs, countIncInstr)) {
            return gadAddr;
        }
    }
    if (gad) {
        gadAddr = FindGadgetEx(gad, count, excludedInstrs, modules);
        *countRet = gad[0].countRet;
    }

    free(gad);
    return gadAddr;
}

BOOL InitExcluded(PEXCLUDED_TYPE* excluded, char** mnem, char** regs, BOOL pMnemPriority, BOOL excludeMem) {
    
    //int factor = excludeMem ? 2 : 1;
    int countOfMnems = 0;
    int countOfregs = 0;

    if (mnem != NULL) {
        while (mnem[countOfMnems] != NULL) {
            countOfMnems++;
        }
    }
    if (regs != NULL) {
        while (regs[countOfregs] != NULL) {
            countOfregs++;
        }
    }
    else {
        *excluded = NULL;
        return TRUE;
    }
    
    ULONG len = ((countOfMnems > 0 ? countOfMnems : 1) *
        (countOfregs > 0 ? countOfregs : 1)) + 1;
    PEXCLUDED_TYPE localExcluded = (PEXCLUDED_TYPE)malloc(sizeof(EXCLUDED_TYPE) * len);
    RtlZeroMemory(localExcluded, sizeof(EXCLUDED_TYPE) * len);

    for (int i = 0; i < len - 1; i++) {
        localExcluded[i].p = TRUE;
    }
    localExcluded[len].p = FALSE;

    char* str = (char*)malloc(32);
    RtlZeroMemory(str, 32);
    int i = 0, j = 0, k = 0;
    BOOL emptyMnem = FALSE;
    ZydisDecoder decoder;
    ZydisDecodedInstruction instr;
    ZyanStatus status;
    status = ZydisInit(&decoder, NULL);
    if (!ZYAN_SUCCESS(status)) {
        free(str);
        return FALSE;
    }

    int countOps = 2;
    do {
        if (countOfMnems == 0) {
            strcat(str, "mov ");
        }
        else {
            if (!strcmp(mnem[i], "j*")) {
                strcat(str, "jmp ");
            }
            else {
                strcat(str, mnem[i]);
                strcat(str, " ");
            }
        }
        if (!strcmp("pop ", str) ||
            !strcmp("push ", str) ||
            !strcmp("inc ", str) ||
            !strcmp("dec ", str) ||
            !strcmp("div ", str) || 
            !strcmp("mul ", str)) {

            countOps = 1;
        }
        else if (!strcmp("leave ", str)) {

            countOps = 0;
        }
        else if (!strcmp("jb ", str) ||
            !strcmp("jbe ", str) ||
            !strcmp("jcx ", str) ||
            !strcmp("jecx ", str) ||
            !strcmp("jl ", str) ||
            !strcmp("jle ", str) ||
            !strcmp("jmp ", str) ||
            !strcmp("jnb ", str) ||
            !strcmp("jnbe ", str) ||
            !strcmp("jnl ", str) ||
            !strcmp("jnle ", str) ||
            !strcmp("jno ", str) ||
            !strcmp("jnp ", str) ||
            !strcmp("jns ", str) ||
            !strcmp("jo ", str) ||
            !strcmp("jp ", str) ||
            !strcmp("js ", str) ||
            !strcmp("jz ", str) ||
            !strcmp("call ", str)) {

            strcat(str, "0x11223344");
            countOps = 0;
        }
        else {
            countOps = 2;
        }

        int mnemLen = strlen(str);
        for (j = 0; j < countOfregs; ++j) {
            int codeSize = 0;
            if (countOps > 0) {
                memcpy(str + mnemLen, regs[j], strlen(regs[j]) + 1);
                
                if (countOps == 2) {
                    strcat(str, ", ");

                    /* PBYTE code = AssembleFasm32(str, &codeSize);
                     if (!code) {
                         printf("[EXCLUDED] error assemble\n");
                         free(str);
                         return FALSE;
                     }
                     status = ZydisDecoderDecodeBuffer(&decoder,
                         code,
                         codeSize,
                         &instr);
                     if (!ZYAN_SUCCESS(status)) {
                         free(code);
                         free(str);
                         return FALSE;
                     }*/
                     /*excluded[i * countOfregs + j + k].mnem = instr.mnemonic;
                     excluded[i * countOfregs + j + k].optype0 = instr.operands[0].type;
                     excluded[i * countOfregs + j + k].reg0 = instr.operands[0].reg.value;*/

                    if (excludeMem) {
                        char* subStr;
                        if (((subStr = strchr(regs[j], 'e')) != NULL)) {
                            strcat(str, "dword [");
                        }
                        else if (((subStr = strchr(regs[j], 'l')) != NULL ||
                            (subStr = strchr(regs[j], 'h')) != NULL)) {

                            strcat(str, "byte [");
                        }
                        else if (((subStr = strchr(regs[j], 'x')) != NULL)) {
                            strcat(str, "word [");
                        }
                        strcat(str, regs[j]);
                        strcat(str, "]");
                    }
                    else {
                        strcat(str, "0");
                    }
                }
            }
            else {
                localExcluded[i * countOfregs + j].mnemPriority = TRUE;
            }

            PBYTE code = AssembleFasm32(str, &codeSize);
            if (!code) {
                printf("[EXCLUDED] error assemble\n");
                free(str);
                return FALSE;
            }
            status = ZydisDecoderDecodeBuffer(&decoder,
                code,
                codeSize,
                &instr);
            if (!ZYAN_SUCCESS(status)) {
                free(code);
                free(str);
                return FALSE;
            }

            localExcluded[i * countOfregs + j].mnem = instr.mnemonic;
            
            switch (countOps) {
            case 2:
            case 0:
                localExcluded[i * countOfregs + j].optype1 = instr.operands[1].type;
                switch (localExcluded[i * countOfregs + j].optype1) {
                case ZYDIS_OPERAND_TYPE_REGISTER:
                case ZYDIS_OPERAND_TYPE_IMMEDIATE:
                    localExcluded[i * countOfregs + j].reg1 = instr.operands[1].reg.value;
                    break;
                case ZYDIS_OPERAND_TYPE_MEMORY:
                    localExcluded[i * countOfregs + j].reg1 = instr.operands[1].mem.base;
                    break;
                }            

            case 1:
                localExcluded[i * countOfregs + j].optype0 = instr.operands[0].type;
                switch (localExcluded[i * countOfregs + j].optype0) {
                case ZYDIS_OPERAND_TYPE_REGISTER:
                    localExcluded[i * countOfregs + j].reg0 = instr.operands[0].reg.value;
                    break;
                case ZYDIS_OPERAND_TYPE_MEMORY:
                    localExcluded[i * countOfregs + j].reg0 = instr.operands[0].mem.base;
                    break;
                }
                
                break;
            }
            
            localExcluded[i * countOfregs + j].mnemPriority = pMnemPriority;

            free(code);
            RtlZeroMemory(str + mnemLen, strlen(str) - mnemLen);
        }
        i++;
        RtlZeroMemory(str, 32);
    } while (i < countOfMnems);

    *excluded = localExcluded;
    return TRUE;
}
