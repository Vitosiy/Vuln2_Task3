#include <NetWorker.h>


SOCKET ConnectToTarget(PCCH ip, USHORT port) {

	WSADATA wsData;
	SOCKET sock;
	SOCKADDR_IN sockaddr;

	if (WSAStartup(0x202, &wsData)) {
		printf("WSAStart error %d\n", WSAGetLastError());
		return INVALID_SOCKET;
	}

	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock  == INVALID_SOCKET) {
		printf("Socket() error %d\n", WSAGetLastError());
		WSACleanup();

		return INVALID_SOCKET;
	}

	sockaddr.sin_family = AF_INET;
	sockaddr.sin_port = htons(port);
	sockaddr.sin_addr.S_un.S_addr = inet_addr(ip);

	if (connect(sock, (PSOCKADDR)&sockaddr, sizeof(sockaddr))) {
		printf("Connect error %d\n", WSAGetLastError());

		CloseSock(&sock);
		WSACleanup();
		return INVALID_SOCKET;
	}

	return sock;
}

BOOL SendToTarget(SOCKET sock, LPVOID data, ULONG len) {
	/*if (len == 0) {
		return TRUE;
	}*/
	if (send(sock, (const char*)data, len, 0) == SOCKET_ERROR) {		
		printf("Error send %d\n", WSAGetLastError());
		return FALSE;
	}

	return TRUE;
}

ULONG RecvFromTarget(SOCKET sock, LPVOID buf, ULONG len) {
	if (len == 0) {
		return 0;
	}
	ULONG recvLen = recv(sock, (char*)buf, len, 0);
	if (recvLen == 0) {
		printf("Nothing recieved!\n");
		//return recvLen;
	}
	else if (recvLen == SOCKET_ERROR) {
		printf("Recv error %d\n", WSAGetLastError());
		return -1;
	}

	return recvLen;
}

BOOL CloseAllConnections(PSOCKETS socks) {

	if (socks->mainSock != INVALID_SOCKET) {
		closesocket(socks->mainSock);
	}
	if (socks->targetSock != INVALID_SOCKET) {
		closesocket(socks->targetSock);
	}

	for (int i = 0; i < COUNT_SOCKS; ++i) {
		CloseSock(&socks->tmpSocks[i]);
	}

	WSACleanup();

	return TRUE;
}

BOOL CloseTmpConnections(PSOCKETS socks) {
	for (int i = 0; i < COUNT_SOCKS; ++i) {
		CloseSock(&socks->tmpSocks[i]);
	}

	return TRUE;
}

void CloseSock(SOCKET *sock) {
	if (*sock != INVALID_SOCKET) {
		closesocket(*sock);
		*sock = INVALID_SOCKET;
	}
}
