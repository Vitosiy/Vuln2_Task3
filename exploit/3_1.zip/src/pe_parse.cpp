/****************************************************************************

    ������ pe_parse.c.

    ������� �������� PE-�����.

    ������ ���� �������������   24.12.2015

****************************************************************************/

#include <stdio.h>
#include "pe_parse.h"

//----------------------------------------

#define INVALID_SECTION_INDEX   0xFFFFFFFF

BOOL ParsePeImage (PBYTE mem, PeHeaders *pe);

DWORD RvaToOffset (DWORD rva, PeHeaders *pe);

DWORD AlignToTop (DWORD value, DWORD align);
DWORD AlignToBottom (DWORD value, DWORD align);

unsigned int GetSectionIndexByName (PeHeaders *pe, char *secname);

void PrintHexLine (unsigned char *line, unsigned int lineSize);

void PrintDump (
    unsigned char *memory, 
    unsigned bytesCount, 
    unsigned int printAddress,
    unsigned int bytesPerLine,
    char *prefixName);

void DumpAllExecutableSections (PeHeaders *pe);

//----------------------------------------


BOOL LoadPeImage(PKERNEL_MODULE mod, PMEM_WORK worker, ULONG base) {

    BOOL retValue;
    DWORD sizeOfImage;
    PBYTE tmpMem;

    tmpMem = (PBYTE)VirtualAlloc(NULL,
        0x1000,
        MEM_RESERVE | MEM_COMMIT,
        PAGE_READWRITE);
    if (!tmpMem) {
        return FALSE;
    }
    if (!MemWork(worker, mem_read, base, (LPVOID)tmpMem, 0x1000)) {
        VirtualFree(mod->pe.mem, 0, MEM_RELEASE);
        mod->pe.mem = NULL;
        return FALSE;
    }
    //mod->pe.doshead = (IMAGE_DOS_HEADER*)tmpMem;
    //mod->pe.nthead = (PIMAGE_NT_HEADERS32)(tmpMem + mod->pe.doshead->e_lfanew);
    sizeOfImage = ((PIMAGE_NT_HEADERS32)(tmpMem + 
        ((PIMAGE_DOS_HEADER)(tmpMem))->e_lfanew))->OptionalHeader.SizeOfImage;
    mod->pe.mem = (PBYTE)VirtualAlloc(NULL,
        sizeOfImage,
        MEM_RESERVE | MEM_COMMIT,
        PAGE_READWRITE);
    if (!mod->pe.mem) {
        return FALSE;
    }

    memcpy(mod->pe.mem, tmpMem, 0x1000);
    VirtualFree(tmpMem, 0, MEM_RELEASE);
    
    ParsePeImage(mod->pe.mem, &mod->pe);

    if (mod->pe.expdir) {
        if (!MemWork(
            worker,
            mem_read,
            base + mod->pe.nthead->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress,
            mod->pe.expdir,
            mod->pe.expdirSize)) {

            VirtualFree(mod->pe.mem, 0, MEM_RELEASE);
            mod->pe.mem = NULL;
            return FALSE;
        }
    }
    
    mod->base = base;
    mod->sizeOfImage = sizeOfImage;
    if (mod->pe.expdir) {
        mod->name = (const char*)(mod->pe.mem + mod->pe.expdir->Name);
    }
    else {
        mod->name = "None";
    }
    // IAT ������
    DWORD IATrva = mod->pe.nthead->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IAT].VirtualAddress;
    mod->IATSize = mod->pe.nthead->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IAT].Size;
    if (!MemWork(worker,
        mem_read,
        base + IATrva,
        mod->pe.mem + IATrva,
        mod->IATSize)) {

        VirtualFree(mod->pe.mem, 0, MEM_RELEASE);
        mod->pe.mem = NULL;
        return FALSE;
    }

    mod->IAT = (PULONG)((ULONG)mod->pe.mem + IATrva);

    // ��������� ������
    mod->secCount = 0;
    SearchAllNeededSection(mod);
    if (!LoadAllNeededSections(mod, worker)) {
        VirtualFree(mod->pe.mem, 0, MEM_RELEASE);
        mod->pe.mem = NULL;
        return FALSE;
    }
    


    return TRUE;
}


//
// ��������� � ������ ����� PE-�����.
//
BOOL ParsePeImage (PBYTE mem, PeHeaders *pe) {


    pe->mem = mem;
    pe->doshead = (IMAGE_DOS_HEADER*) pe->mem;
    pe->nthead = (IMAGE_NT_HEADERS*)(pe->mem + pe->doshead->e_lfanew);
    pe->sections = (IMAGE_SECTION_HEADER*)((DWORD) &(pe->nthead->OptionalHeader) + pe->nthead->FileHeader.SizeOfOptionalHeader);
    pe->secCount = pe->nthead->FileHeader.NumberOfSections;

    // �������� ��������� �� ��������
    if (pe->nthead->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress) {
        pe->expdir = (IMAGE_EXPORT_DIRECTORY*)
            (pe->mem + pe->nthead->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress);
        pe->expdirSize = pe->nthead->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].Size;
        }
    else {
        pe->expdir = 0;
        pe->expdirSize = 0;
        }

    // �������� ���������� �� �������
    if (pe->nthead->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress) {
        pe->impdir = (IMAGE_IMPORT_DESCRIPTOR*)
            (pe->mem + pe->nthead->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
        pe->impdirSize = pe->nthead->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].Size;
        }
    else {
        pe->impdir = 0;
        pe->impdirSize = 0;
        }

    return TRUE;
}

BOOL LoadAllNeededSections(PKERNEL_MODULE mod, PMEM_WORK worker) {
    
    for (int i = 0; i < mod->secCount; ++i) {
        if (!MemWork(worker,
            mem_read,
            mod->base + mod->codeSections[i].VirtualAddress,
            mod->pe.mem + mod->codeSections[i].VirtualAddress,
            mod->codeSections[i].SizeOfRawData)) {

            return FALSE;
        }
    }
    
    return TRUE;
}

ULONG FindExportByName(PeHeaders* pe, PMEM_WORK worker, const char* name, ULONG base) {
    
    ULONG retValue = 0;
    PWORD nameOrdinalsArray;
    PDWORD namesArray, functionsArray;
    DWORD i = 0;

    if (pe->expdir == 0 || pe->expdirSize == 0) {
        return retValue;
    }

    functionsArray = (PDWORD)((ULONG)pe->mem + pe->expdir->AddressOfFunctions);
    namesArray = (PDWORD)((ULONG)pe->mem + pe->expdir->AddressOfNames);
    nameOrdinalsArray = (PWORD)((ULONG)pe->mem + pe->expdir->AddressOfNameOrdinals);

    for (i = 0; i < pe->expdir->NumberOfNames; i++) {
        if (!strcmp(name, (const char*)((ULONG)pe->mem + namesArray[i]))) {
            
            /*if (!MemWork(worker,
                mem_read,
                base + functionsArray[nameOrdinalsArray[i]],
                &retValue,
                4)) {

                retValue = 0;
            }*/
            retValue = base + functionsArray[nameOrdinalsArray[i]];
            //retValue = functionsArray[nameOrdinalsArray[i]];
            break;
        }
    }


    return retValue;
}

bool ModIsExist(KERNEL_MODULE& lhs) {

    return false;
}

BOOL GetAllModulesByIAT(std::vector<KERNEL_MODULE>& modules, PMEM_WORK worker, KERNEL_MODULE& startModule) {
    
    PULONG currIAT = startModule.IAT;

    while (TRUE) {
        if (currIAT == (PULONG)(startModule.IAT + startModule.IATSize)) {
            //printf("[GET MODULES] End IAT for %08X\n", startModule.base);
            break;
        }
        if (*currIAT == 0) {
            currIAT++;
            continue;
        }
        // ?
        BOOL next = FALSE;
        for (auto& mod : modules) {
            if ((*currIAT >= mod.base) && (*currIAT < (mod.base + mod.sizeOfImage))) {
                next = TRUE;
                break;
            }
        }
        if (next) {
            currIAT++;
            continue;
        }
        else {
            PKERNEL_MODULE newMod = new KERNEL_MODULE;
            ULONG base = 0;
            if (!FindImageBaseByAddr(worker, *currIAT, &base)) {
                printf("[GET MODULES] Error find IB for %08X\n", *currIAT);
                delete newMod;
                return FALSE;
            }
            if (base != 0) {
                if (!LoadPeImage(newMod, worker, base)) {
                    printf("[GET MODULES] Error load pe for %08X\n", *currIAT);
                    delete newMod;
                    return FALSE;
                }
                modules.push_back(*newMod);
                printf("[GET MODULES] add new module %s: base = %08X\n", newMod->name, newMod->base);
            }
            GetAllModulesByIAT(modules, worker, static_cast<KERNEL_MODULE&>(*newMod));
        }
        currIAT++;
    }
    
    return TRUE;
}

ULONG FindFreePlaceInSection(PKERNEL_MODULE module, ULONG neededLen) {

    ULONG addr = 0;

    for (int i = 0; i < module->secCount - 1; i++) {
        PIMAGE_SECTION_HEADER currSec = &module->codeSections[i];
        if ((module->codeSections[i + 1].VirtualAddress - (currSec->VirtualAddress + currSec->Misc.VirtualSize)) > neededLen) {
            addr = module->base + currSec->VirtualAddress + currSec->Misc.VirtualSize;
            break;
        }
    }

    return addr;
}

BOOL SearchAllNeededSection(PKERNEL_MODULE mod) {
   
    for (int i = 0; i < mod->pe.secCount; ++i) {
        PIMAGE_SECTION_HEADER section = &mod->pe.sections[i];
        if((section->Characteristics & IMAGE_SCN_MEM_EXECUTE) &&
            !(section->Characteristics & IMAGE_SCN_MEM_DISCARDABLE)) {

            mod->secCount++;
        }
    }

    mod->codeSections = (PIMAGE_SECTION_HEADER)malloc(sizeof(IMAGE_SECTION_HEADER) * mod->secCount);

    int j = 0;
    for (int i = 0; i < mod->pe.secCount; ++i) {
        PIMAGE_SECTION_HEADER section = &mod->pe.sections[i];
        if ((section->Characteristics & IMAGE_SCN_MEM_EXECUTE) &&
            !(section->Characteristics & IMAGE_SCN_MEM_DISCARDABLE)) {

            if(mod->pe.nthead->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IAT].VirtualAddress == 
                section->VirtualAddress) {

                mod->codeSections[j] = mod->pe.sections[i];
                mod->codeSections[j].VirtualAddress +=
                    mod->pe.nthead->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IAT].Size;
                
                j++;
                continue;
            }
            mod->codeSections[j++] = mod->pe.sections[i];
        }
    }

    return TRUE;
}

BOOL FindImageBaseByAddr(PMEM_WORK worker, ULONG addr, LPVOID base) {
    ULONG tmpAddr = (addr - 0x1000) & 0xFFFFF000;

    ULONG value;
    while (TRUE) {
        //if ((tmpAddr % 16) == 0) {
        printf("\r%08X ", tmpAddr);
        //}
        if (!MemWork(worker,
            mem_read,
            tmpAddr,
            &value,
            4)) {

            *(PULONG)base = 0;
            //CloseAllConnections(&socks);
            return FALSE;
        }

        if ((value & 0x00FFFFFF) == 0x905a4d) {
            *(PULONG)base = tmpAddr;
            //printf("\nFind IB kernel : %08X\n", tmpAddr);
            break;
        }

        tmpAddr -= 0x1000;
    }
    printf("\r        \r");
    return TRUE;
}

//--------------------


//
// ���������� �������� �������� �� RVA.
//
DWORD RvaToOffset (DWORD rva, PeHeaders *pe) {

    unsigned int i;
    IMAGE_SECTION_HEADER *sections = pe->sections;
    unsigned int secCount = pe->secCount;


    if (rva > pe->nthead->OptionalHeader.SizeOfImage){
        return 0;
        }

    //�������� �� ���� ������� � ����
    //� ����� �������� RVA
    for (i = 0; i < secCount; ++i) {
        if( (rva >= sections[i].VirtualAddress) && 
            (rva <= sections[i].VirtualAddress + sections[i].Misc.VirtualSize))
            return rva - sections[i].VirtualAddress + sections[i].PointerToRawData;
        }

    return 0;
}


//--------------------


//
// ����������� �������� � ���������� align � ������� �������.
//
DWORD AlignToTop (DWORD value, DWORD align) {


    DWORD mask = ~ (align - 1);

    return (value + align - 1) & mask;
}


//--------------------


//
// ����������� �������� � ���������� align � ������ �������.
//
DWORD AlignToBottom (DWORD value, DWORD align) {


    DWORD mask = ~ (align - 1);

    return value & mask;
}


//--------------------

//
// ���������� ������ ������ �� �����
//
unsigned int GetSectionIndexByName (PeHeaders *pe, char *sectionName) {


    unsigned int indexSec;

    for (indexSec = 0; indexSec < pe->secCount; ++indexSec) {
        
        if (!_strnicmp ((const char*)pe->sections[indexSec].Name, sectionName, 8)) {
            return indexSec;
            }
        }

    return INVALID_SECTION_INDEX;
}


//--------------------


//
// ������� ���� ������ ����������������� ��������.
//
void PrintHexLine (unsigned char *line, unsigned int lineSize) {

unsigned int i;

    // ����� ASCII-��������
    for (i = 0; i < lineSize; ++i) {
        printf ("%02X ", line[i]);
        }

    printf ("  ");

    // ����� ��������
    for (i = 0; i < lineSize; ++i) {

        if (isprint (line[i])) {
            printf ("%c", line[i]);
            }
        else {
            printf (" ");
            }

        }

    return;
}


//--------------------


//
// ������� ���� ������ � ����������������� ����.
//
void PrintDump (
    unsigned char *memory, 
    unsigned bytesCount, 
    unsigned int printAddress,
    unsigned int bytesPerLine,
    char *prefixName) {

unsigned int bytesIndex;
unsigned char *line = (unsigned char*) malloc (bytesPerLine);
unsigned int lineIndex = 0;

    for (bytesIndex = 0; bytesIndex < bytesCount; ++bytesIndex) {

        if (bytesIndex % bytesPerLine == 0) {
            printf ("%s %p: ", prefixName, printAddress + bytesIndex);
            }

        line[lineIndex++] = memory[bytesIndex];

        // ���� ����� ��������� ������
        if ((bytesIndex + 1) % bytesPerLine == 0) {

            PrintHexLine (line, bytesPerLine);
            printf ("\n");

            lineIndex = 0;

            }
        }

    free (line);

    return;
}


//--------------------


//
// ������� ����������������� ���� ����������� ������.
//
void DumpAllExecutableSections (PeHeaders *pe) {

DWORD i;

    for (i = 0; i < pe->secCount; ++i) {
        IMAGE_SECTION_HEADER *section = &pe->sections[i];
        if (section->Characteristics & IMAGE_SCN_MEM_EXECUTE) {
            PrintDump (
                pe->mem + section->VirtualAddress,
                section->Misc.VirtualSize,
                (unsigned int)pe->mem + section->VirtualAddress,
                16,
                (char*)section->Name);
            }
        }

    return;
}


//--------------------


//
// ������������ ����� ������������������ ���� � ������� ������.
//
BYTE* SearchBytesInRegion (BYTE *pattern, DWORD patternSize, BYTE *startRegion, DWORD regionSize) {

DWORD i;

    for (i = 0; i < regionSize - patternSize + 1; ++i) {
        if (!memcmp (pattern, startRegion + i, patternSize)) {
            return startRegion + i;
            }
        }

    return NULL;
}


//--------------------


//
// ���������� ����� �������������� �������.
//
DWORD SearchGadget (PeHeaders *pe, BYTE *gadget, DWORD gadgetSize) {

DWORD i;

    for (i = 0; i < pe->secCount; ++i) {
        IMAGE_SECTION_HEADER *section = &pe->sections[i];
        if (section->Characteristics & IMAGE_SCN_MEM_EXECUTE) {
            BYTE *startSection = pe->mem + section->VirtualAddress;
            BYTE *gadgetAddr = SearchBytesInRegion (gadget, gadgetSize, startSection, section->Misc.VirtualSize);
            if (gadgetAddr) {
                DWORD gadgetRva = gadgetAddr - pe->mem;
                //printf ("%08X (%s + %d) rva: %d\n", gadgetAddr, section->Name, gadgetAddr - (startSection), gadgetRva);
                return gadgetRva;
                }
            }
        }

    return 0;
}


//--------------------


//
// ���������� rva �������������� ������� � ������.
//
DWORD SearchGadgetInSection (PeHeaders *pe, BYTE *gadget, DWORD gadgetSize, char *sectionName) {

    DWORD sectionIndex = GetSectionIndexByName (pe, sectionName);
    if (sectionIndex != INVALID_SECTION_INDEX) {
        IMAGE_SECTION_HEADER *section = &pe->sections[sectionIndex];
        BYTE *startSection = pe->mem + section->VirtualAddress;
        BYTE *gadgetAddr = SearchBytesInRegion (gadget, gadgetSize, startSection, section->Misc.VirtualSize);
        if (gadgetAddr) {
            DWORD gadgetRva = gadgetAddr - pe->mem;
            //printf ("%08X (%s + %d) rva: %d\n", gadgetAddr, section->Name, gadgetAddr - (startSection), gadgetRva);
            return gadgetRva;
            }
        }

    return 0;
}



//--------------------


//
// ������� ��� ������ �������������� ROP-������� �� ���� ����������� �������.
//
void PrintAllGadget (PeHeaders *pe, BYTE *gadget, DWORD gadgetSize) {

DWORD i;

    for (i = 0; i < pe->secCount; ++i) {
        IMAGE_SECTION_HEADER *section = &pe->sections[i];
        if (section->Characteristics & IMAGE_SCN_MEM_EXECUTE) {
            BYTE *startSection = pe->mem + section->VirtualAddress;
            BYTE *gadgetAddr = SearchBytesInRegion (gadget, gadgetSize, startSection, section->Misc.VirtualSize);
            if (gadgetAddr) {
                DWORD gadgetRva = gadgetAddr - pe->mem;
                printf ("%08X (%s + %d) rva: %d\n", gadgetAddr, section->Name, gadgetAddr - (startSection), gadgetRva);
                }
            }
        }

    return;
}


//--------------------

//--------------------

