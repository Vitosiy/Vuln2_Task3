#ifndef  __NET_WORKER_H__
#define __NET_WORKER_H__

#include <includes.h>



SOCKET ConnectToTarget(
	PCCH ip,
	USHORT port
);

BOOL SendToTarget(
	SOCKET sock,
	LPVOID data,
	ULONG len
);

ULONG RecvFromTarget(
	SOCKET sock,
	LPVOID buf,
	ULONG len
);

BOOL CloseAllConnections(
	PSOCKETS socks
);

void CloseSock(
	SOCKET* sock
);

BOOL CloseTmpConnections(
	PSOCKETS socks
);

#endif // ! __NET_WORKER_H__
