/****************************************************************************

    ���� fasm.h 

    ������������ ���� ��� ���������� fasm.dll.

****************************************************************************/

#ifndef _FASM_H_
#define _FASM_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _FASM_STATE {

    unsigned int condition;
    union {
        unsigned int output_length;
        unsigned int error_code;
        };
    union {
        unsigned char *output_data;
        unsigned int error_line;
        };

    unsigned char buf[];

} FASM_STATE;

unsigned int __stdcall fasm_Assemble (char * szSource, FASM_STATE *state, int stateSize, int nPassesLimit, void *hDisplayPipe);

unsigned int __stdcall fasm_AssembleFile (char *fileName);

unsigned int __stdcall fasm_GetVersion (void);


#ifdef __cplusplus
}
#endif

#endif  // _FASM_H_
