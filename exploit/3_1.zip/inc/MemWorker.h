#pragma once

#include <includes.h>
#include <NetWorker.h>

#define GET_INDEX(diff) \
    ((((diff) - 0x408 - 4) / 4))

#define GET_INDEX_UP(addr, offset) \
    ((((addr) + (offset)) - (addr)) / 4)

#define GET_INDEX_DOWN(addr, offset) \
    ((((addr) - ((addr) - (offset))) / 4) * (-1))

//extern BOOL glIsStart = FALSE;

typedef enum _MEM_OP_ {
    mem_read = 1,
    mem_write = 2,

    unknown = 0,
}MEM_OP;

BOOL WriteMem(
    IN SOCKET sock,
    IN int index,
    IN LPVOID lpData
);

BOOL ReadMem(
    IN SOCKET sock,
    IN int index,
    OUT LPVOID lpData
);

BOOL ReadMemByAddr(
    IN SOCKET sock,
    IN ULONG workerStack,
    IN ULONG addr,
    OUT LPVOID buf,
    IN ULONG len
);

BOOL MemWork(
    IN PMEM_WORK worker,
    IN MEM_OP operation,
    IN ULONG addr,
    IN OUT LPVOID buf,
    IN ULONG len
);

BOOL WriteMemByAddr(
    IN SOCKET sock,
    IN ULONG workerStack,
    IN ULONG addr,
    IN LPVOID buf,
    IN ULONG len
);

BOOL WriteMemByAddr2(
    IN PMEM_WORK worker,
    IN ULONG addr,
    IN LPVOID buf,
    IN ULONG len
);

BOOL SelectConnection(
    IN OUT PSOCKETS socks,
    IN ULONG workerStack,
    OUT PULONG targetStack,
    IN OUT PULONG diffStacks,
    OUT PBOOL isUp
);

BOOL StartMemWork(
    IN OUT PMEM_WORK worker
);

BOOL CloseMemWork(
    IN OUT PMEM_WORK worker
);